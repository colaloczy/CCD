using System;

namespace v0_0004
{
    class Program
    {
        static void Main(string[] args)
        {
            string line;
            while (!string.IsNullOrEmpty(line = Console.ReadLine()))
            {
                var input = line.Split(' ');
                var a = double.Parse(input[0]);
                var b = double.Parse(input[1]);
                var c = double.Parse(input[2]);
                var d = double.Parse(input[3]);
                var e = double.Parse(input[4]);
                var f = double.Parse(input[5]);

                double y = Math.Round((c * d - f * a) / (b * d - e * a), 3);
                double x = Math.Round((c - y * b) / a, 3);

                Console.WriteLine("{0:f3} {1:f3}", x, y);
            }
        }
    }
}