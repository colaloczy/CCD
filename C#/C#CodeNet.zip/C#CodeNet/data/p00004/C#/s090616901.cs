using System;
using System.Linq;

class SimultaneousEquation 
{
    static void Main()
    {
        Func<double, double> round = 
            k => (int)( k * 10000 + ( k < 0 ? -5 : 5 ) ) / 10 / 1000d;
        var q =
            from se in 
                from p in GetProblems()
                select p.Split( ' ' ).Select( _ => double.Parse( _ ) )
            let a = se.Skip( 0 ).First()
            let b = se.Skip( 1 ).First()
            let c = se.Skip( 2 ).First()
            let d = se.Skip( 3 ).First()
            let e = se.Skip( 4 ).First()
            let f = se.Skip( 5 ).First()
            let x = ( c / b - f / e ) / ( a / b - d / e )
            let y = ( c - a * x ) / b
            select 
                round( x ).ToString( "0.000" ) + " " + 
                round( y ).ToString( "0.000" );
        Console.Write( string.Join( "\n", q ) );
    }

    static System.Collections.Generic.IEnumerable<string> GetProblems()
    {
        string buffer = "";
        while ( ( buffer = Console.ReadLine() ) != null )
            yield return buffer;
    }
}