using System;
using System.Linq;

namespace _0004
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                string s = Console.ReadLine();
                if (string.IsNullOrEmpty(s)) break;
                double[] x = s.Split().Select(double.Parse).ToArray();
                double a = (x[1] * x[5] - x[2] * x[4]) / (x[1] * x[3] - x[0] * x[4]);
                double b = (x[0] * x[5] - x[2] * x[3]) / (x[0] * x[4] - x[1] * x[3]);
                Console.Write(a.ToString("F3") + " ");
                Console.WriteLine(b.ToString("F3"));
            }
        }
    }
}
