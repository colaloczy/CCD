using System;
using System.Linq;

namespace id_0004
{
    class Program
    {
        static void Main(string[] args)
        {
            string line;
            while((line = Console.ReadLine()) != null)
            {
                double[] coefficients = line.Trim().Split(' ').Select(a => double.Parse(a)).ToArray();
                double x = Math.Round((coefficients[2] * coefficients[4] - coefficients[1] * coefficients[5]) / (coefficients[0] * coefficients[4] - coefficients[1] * coefficients[3]),3,MidpointRounding.AwayFromZero);
                double y = Math.Round((coefficients[0] * coefficients[5] - coefficients[2] * coefficients[3]) / (coefficients[0] * coefficients[4] - coefficients[1] * coefficients[3]),3,MidpointRounding.AwayFromZero);
                Console.WriteLine("{0:f3} {1:f3}", x,y);
            }
        }
    }
}

