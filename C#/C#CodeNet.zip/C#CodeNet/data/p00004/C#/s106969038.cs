using System;
class main
{
    static void Main(string[] args)
    {
    string s = Console.ReadLine();

        if (s != null)
        {
            string[] t = s.Split(' ');
            double[] u = new double[6];

            for (int i = 0; i < t.Length; ++i)
            {
                u[i] = double.Parse(t[i]);
            }

            double y = ((u[2] * u[3]) - (u[5] * u[0])) / ((u[1] * u[3]) - (u[4] * u[0]));
            double x = (u[2] - (y * u[1])) / u[0];

            Console.WriteLine("{0:f3} {1:f3}", x, y);
        }
        Console.ReadKey();
    }
}