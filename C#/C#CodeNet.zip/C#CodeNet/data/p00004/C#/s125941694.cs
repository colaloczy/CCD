using System;
using System.Linq;

class SimultaneousEquation 
{
    static void Main()
    {
        var q =
            from se in 
                from p in GetProblems()
                select p.Split( ' ' ).Select( _ => double.Parse( _ ) )
            let a = se.Skip( 0 ).First()
            let b = se.Skip( 1 ).First()
            let c = se.Skip( 2 ).First()
            let d = se.Skip( 3 ).First()
            let e = se.Skip( 4 ).First()
            let f = se.Skip( 5 ).First()
            let x = ( c * e - f * b ) / ( a * e - d * b )
            let y = ( c - a * x ) / b
            select 
                x.ToString( "F3" ) + " " + 
                y.ToString( "F3" );
        Console.Write( string.Join( "\n", q ) );
    }

    static System.Collections.Generic.IEnumerable<string> GetProblems()
    {
        string buffer = "";
        while ( ( buffer = Console.ReadLine() ) != null )
            yield return buffer;
    }
}