using System;
using System.Linq;

namespace _0004
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                string input = Console.ReadLine();
                if (string.IsNullOrEmpty(input))
                {
                    break;
                }
                else
                {
                    int[] x = input.Split().Select(int.Parse).ToArray();
                    double a = x[0];
                    double b = x[1];
                    double c = x[2];
                    double d = x[3];
                    double e = x[4];
                    double f = x[5];
                    double retx = (c / b - f / e) / (a / b - d / e);
                    double rety = (c / a - f / d) / (b / a - e / d);
                    Console.WriteLine(retx + " " + rety);
                }
            }
        }
    }
}