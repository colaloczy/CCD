using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0004
{
    class Program
    {
        static void Main(string[] args)
        {
            // 連立方程式 ax + by = c,dx + ey = f の解、x,yを出力するプログラム
            // 1行ごとにa,b,c,d,e,fがスペース区切りで与えられる

            string str;

            while ((str = Console.ReadLine()) != null)
            {
                double[] num = str.Split(' ').Select(double.Parse).ToArray();
                double a = num[0]; double b = num[1]; double c = num[2];
                double d = num[3]; double e = num[4]; double f = num[5];

                double x = (b * f - c * e) / (b * d - a * e);
                double y = (c - a * x) / b;

                Console.WriteLine(x.ToString("F3") + " " + y.ToString("F3"));
            }
        }
    }
}

