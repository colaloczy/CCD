using System;

class AOJ
{
  static void Main(string[] args)
  {
    string s;

    while ((s = Console.ReadLine()) != null)
    {
      var z = Array.ConvertAll(Console.ReadLine().Split(' '), int.Parse);

      double a = z[0], b = z[1], c = z[2], d = z[3], e = z[4], f = z[5];

      double x = (e * c - b * f) / (e * a - b * d);
      double y = (c * d - a * f) / (b * d - e * a);

      if (x == -0.0) x = 0;
      if (y == -0.0) y = 0;

      Console.WriteLine("{0:F3} {1:F3}", x, y);
    }
  }
}