using System;
using System.Collections.Generic;
using System.Linq;
namespace csharptest
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            double []x = new double[200];
            double []y = new double[200];
            while (true)
            { 
                string str = Console.ReadLine();
                if (String.IsNullOrEmpty(str) == false)
                {
                    string[] s = str.Split(' ');
                    double a = double.Parse(s[0]);
                    double b = double.Parse(s[1]);
                    double c = double.Parse(s[2]);
                    double d = double.Parse(s[3]);
                    double e = double.Parse(s[4]);
                    double f = double.Parse(s[5]);
                    y[i] = Math.Round((a * f - c * d) / (a * e - b * d), 3);
                    x[i] = Math.Round((b * f - e * c) / (b * d - e * c), 3);
                    i++;
                    // nullではなく、かつ空文字列でもない
                }
                else
                {
                    break;
                    // null、もしくは空文字列である
                }
            }
            for (int n = 0; n < i; n++)
            {
                Console.WriteLine(x[i] + " " + y[i]);
            }
        }
    }
}