using System;
using System.IO;
using System.Linq;

namespace Simultaneous_Equation
{
	class Program
	{
		static void Main(string[] args)
		{
			var result = Enumerable.Range(0, int.MaxValue)
				.Select(_ => Console.ReadLine())
				.TakeWhile(x => x != null)
				.Select(x => x.Split(' ').Select(y => double.Parse(y)).ToArray())
				.Select(x => new {
					X = (x[2] * x[4] - x[1] * x[5]) / (x[0] * x[4] - x[1] * x[3]),
					Y = (x[0] * x[5] - x[2] * x[3]) / (x[0] * x[4] - x[1] * x[3])
				});

			foreach (var item in result) {
				Console.WriteLine("{0:f3} {1:f3}", item.X, item.Y);
			}
		}
	}
}