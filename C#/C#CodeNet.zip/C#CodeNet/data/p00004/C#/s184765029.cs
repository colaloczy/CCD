using System;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                string r = Console.ReadLine();
                if (r == null) break;
                double[] k0 = new double[6];
                for (int i = 0; i < 6; i++) k0[i] = double.Parse(r.Split(' ')[i]);
                string x, y;
                y = ((k0[2] * k0[3] - k0[0] * k0[5]) / (k0[1] * k0[3] - k0[0] * k0[4])).ToString();
                x = ((k0[2] - k0[1] * double.Parse(y)) / (k0[0])).ToString();
                Console.WriteLine(String.Format("{0:0.000} {1:0.000}", double.Parse(x), double.Parse(y)));
            }
        }
    }
}