using System;
using System.Linq;

class Program {
    static void Main() {
        string s;
        while ((s = Console.ReadLine()) != null) {
            double[] n = s.Split().Select(double.Parse).ToArray();
            double a = n[0];
            double b = n[1];
            double c = n[2];
            double d = n[3];
            double e = n[4];
            double f = n[5];
            double y = (c * d - a * f) / (b * d - a * e);
            double x = (c - b * y) / a;
            Console.WriteLine("{0:f3} {1:f3}", x, y);
        }
    }
}
