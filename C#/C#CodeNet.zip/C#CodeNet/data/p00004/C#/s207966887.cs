using System;
using System.Linq;

namespace _0004
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                string input = Console.ReadLine();
                if (input.Length == 0) break;
                int[] x = input.Split(' ').Select(int.Parse).ToArray();
                int a = x[0];
                int b = x[1];
                int c = x[2];
                int d = x[3];
                int e = x[4];
                int f = x[5];
                int t, e1,ipo;
                int c1 = d / a * b;
                t = e - b;
                e1 = f - c1;
                if (b == e) 
                {
                    ipo = d-a;
                    
                    int x1 =e1/ipo ;
                    int y = (c - a * x1) / b;
                    Decimal result;
                    result = Math.Round((decimal)y, 3, MidpointRounding.AwayFromZero);

                    Decimal result2;
                    result2 = Math.Round((decimal)x1, 3, MidpointRounding.AwayFromZero);

                    Console.WriteLine("" + result.ToString("0.000") + " " + result2.ToString("0.000") + "");
                    Console.ReadLine();
                }
                else
                {
                    int y = e1 / t;
                    int x1 = (c - b * y) / a;
                    Decimal result;
                    result = Math.Round((decimal)y, 3, MidpointRounding.AwayFromZero);

                    Decimal result2;
                    result2 = Math.Round((decimal)x1, 3, MidpointRounding.AwayFromZero);

                    Console.WriteLine("" + result.ToString("0.000") + " " + result2.ToString("0.000") + "");
                    Console.ReadLine();
                }
            }
        }
    }
}