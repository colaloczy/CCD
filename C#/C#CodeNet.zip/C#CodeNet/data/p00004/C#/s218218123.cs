using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp16
{
     class Program
    {
        public static void Main(string[] args)
        {
            while (true)
            {
                string a = Console.ReadLine();
                if (a == null) break;
                decimal[] b = a.Split().Select(decimal.Parse).ToArray();
                decimal[] c = {b[1]*b[3]/b[0],b[2]*b[3]/b[0]};
                decimal d = b[5] - c[1] / (b[4] - c[0]);
                decimal e = (b[2] - d) / b[0];
                Console.WriteLine("{0,##########.000} {1,#########.000}",e,d);
            }
        }
    }
}