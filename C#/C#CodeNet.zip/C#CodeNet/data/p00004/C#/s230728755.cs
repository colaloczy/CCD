using System;


class AOJ
{

    public static void Main()
    {

        while (true)
        {
            string ss = Console.ReadLine();
            if (ss == null) break;

            string[] s = ss.Split(' ');

            int[] a = new int[6];

            for (int i = 0; i < 6; i++)
            {
                a[i] = int.Parse(s[i]);
            }

            double x = (a[2] * a[4] - a[1] * a[5]) / (a[0] * a[4] - a[1] * a[3]);

            double y = (a[0] * a[5] - a[2] * a[3]) / (a[0] * a[4] - a[1] * a[3]);

            Console.WriteLine("{0:##0.000} {1:##0.000}", Math.Round(x, 4, MidpointRounding.AwayFromZero), Math.Round(y, 4, MidpointRounding.AwayFromZero));
        }
    }
}