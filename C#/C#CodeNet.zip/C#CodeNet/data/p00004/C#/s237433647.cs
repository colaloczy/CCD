using System;

public class Program {
    public static void Main() {
        while (true) {
            string input = Console.ReadLine();
            if (input == null) break;
            decimal[] num = Array.ConvertAll(input.Split(' '), value => decimal.Parse(value));
            Console.WriteLine(Math.Round((num[2]*num[4]-num[5]*num[1])/(num[4]*num[0]-num[1]*num[3]), 3, MidpointRounding.AwayFromZero).ToString()+" "+(Math.Round((num[2]*num[3]-num[5]*num[0])/(num[1]*num[3]-num[4]*num[0]), 3, MidpointRounding.AwayFromZero)).ToString());
        }
    }
}