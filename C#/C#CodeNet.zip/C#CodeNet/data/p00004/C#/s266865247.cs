using System;

class FIVE
{
	static void Main() {
		string output = "";
		bool ZZ = true;
		while(ZZ){
			string datas = Console.ReadLine();
			if(datas.Length < 1) break;
			string[] numsText = datas.Split(' ');
			double[] nums = new double[numsText.Length];
			for(int i=0; i<numsText.Length; ++i)
			{
				nums[i] = double.Parse(numsText[i]);
			}
			double xCo = nums[0] * nums[3] / Gcd(nums[0], nums[3]);

			double bi1 = xCo / nums[0],
			bi2 = xCo / nums[3];

			double reY1 = bi1 * nums[1],
			reY2 = bi2 * nums[4],
			reRe1 = bi1 * nums[2],
			reRe2 = bi2 * nums[5];

			double reYLast = reY1 - reY2,
			reReLast = reRe1 - reRe2;

			double reY = Math.Round((reReLast / reYLast) * 1000) / 1000.0;

			double reX = Math.Round((nums[2] - (nums[1] * reY)) / nums[0] * 1000) / 1000.0;

			if(output.Length < 1) output = reX.ToString("F3")+" "+reY.ToString("F3");
			else output += "\n"+reX.ToString("F3")+" "+reY.ToString("F3");
		}


		Console.WriteLine(output);
		
	}


	public static double Gcd(double a, double b) {
		if (a < b) return Gcd(b, a);
		while (b != 0) {
			var remainder = a % b;
			a = b;
			b = remainder;
		}
		return a;
	}
}