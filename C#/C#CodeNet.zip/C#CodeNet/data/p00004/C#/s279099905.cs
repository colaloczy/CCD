using System;
using System.Collections.Generic;
class _0004
{
    public static void Main()
    {
        char[] splitChar = { ' ' };
        List<double> ansx = new List<double>();
        List<double> ansy = new List<double>();
        double det;
        double[] data = new double[6];
        string str;
        while ((str = Console.ReadLine()) != null)
        {
            string[] nums = str.Split(splitChar);
            int l = 0;
            foreach (string num in nums)
            {
                data[l] = double.Parse(num);
                l++;
            }
            det = data[0] * data[4] - data[1] * data[3];
            ansx.Add((data[4] * data[2] - data[1] * data[5]) / det);
            ansy.Add((data[0] * data[5] - data[3] * data[2]) / det);
        }
        for (int i = 0; i < ansx.Count; i++) Console.WriteLine(ansx[i].ToString("f3") + " " + ansy[i].ToString("f3"));
    }
}