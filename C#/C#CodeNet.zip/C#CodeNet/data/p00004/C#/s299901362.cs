using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simultaneous_Equation
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                string input = Console.ReadLine();
                if (input == null)
                { break; }

                string[] nums = input.Split(' ');
                double a = double.Parse(nums[0]);
                double b = double.Parse(nums[1]);
                double c = double.Parse(nums[2]);
                double d = double.Parse(nums[3]);
                double e = double.Parse(nums[4]);
                double f = double.Parse(nums[5]);

                double x = (c * e - f * b) / (a * e - b * d);
                double y = (c * d - a * f) / (b * d - a * e);

                Console.Write("{0:0.000}", x);
                Console.Write(" ");
                Console.Write("{0:0.000}", y);
                Console.WriteLine();
            }
        }
    }
}

