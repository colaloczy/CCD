using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                string input = Console.ReadLine();

                if (string.IsNullOrEmpty(input)) break;

                double[] nums = Array.ConvertAll(input.Split(' '), double.Parse);

                double a = nums[0], b = nums[1], c = nums[2];
                double d = nums[3], e = nums[4], f = nums[5];

                double x = (b * f - e * c) / (b * d - a * e);
                double y = (a * f - d * c) / (a * e - b * d);

                Console.WriteLine("{0:f3} {1:f3}",
                    Math.Round(x, 3, MidpointRounding.AwayFromZero),
                    Math.Round(y, 3, MidpointRounding.AwayFromZero));
            }
        }
    }
}