using System;
using System.Collections.Generic;

class Program {
    static int Main(string[] args) {
        List<decimal[]> list = new List<decimal[]>();

        while (true) {
            string v = Console.ReadLine();
            if (v.Trim().Length == 0) { break; }

            string[] vs = v.Split(' ');
            decimal[] vd = new decimal[6];

            for (int i = 0; i < 6; i++) {
                vd[i] = decimal.Parse(vs[i]);
            }
            list.Add(vd);
        }

        for (int i = 0; i < list.Count; i++) {
            decimal a = list[i][0];
            decimal b = list[i][1];
            decimal c = list[i][2];
            decimal d = list[i][3];
            decimal e = list[i][4];
            decimal f = list[i][5];

            decimal x = a;//Math.Round((b * f - c * e) / (b * d - a * e), 3, MidpointRounding.AwayFromZero);
            decimal y = b;//Math.Round((a * f - c * d) / (a * e - b * d), 3, MidpointRounding.AwayFromZero);

            Console.WriteLine(string.Format("{0:f3} {1:f3}", x, y));
        }

        return 0;
    }
}