using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                string line = System.Console.ReadLine();
                if (line == null || line == "")
                {
                    return;
                }
                string[] param = line.Split(' ');
                double a = double.Parse(param[0]);
                double b = double.Parse(param[1]);
                double c = double.Parse(param[2]);
                double d = double.Parse(param[3]);
                double e = double.Parse(param[4]);
                double f = double.Parse(param[5]);

                double x = 0;
                double y = 0;

                // ax + by = c
                // dx + ey = f
                y = (c / a - f / d) / (b / a - e / d);
                x = (c - b * y) / a;
                System.Math.Round(x, 4, MidpointRounding.AwayFromZero);
                System.Math.Round(y, 4, MidpointRounding.AwayFromZero);
                System.Console.WriteLine(string.Format("{0:f3}", x) + " " + string.Format("{0:f3}", y));
                System.Console.ReadLine();
            }

        }
    }
}