using System;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                string r = Console.ReadLine();
                if (r == null) break;
                double[] k0 = new double[6];
                 k0[0] = double.Parse(r.Split(' ')[0]);
                 k0[1] = double.Parse(r.Split(' ')[1]);
                 k0[2] = double.Parse(r.Split(' ')[2]);
                 k0[3] = double.Parse(r.Split(' ')[3]);
                 k0[4] = double.Parse(r.Split(' ')[4]);
                 k0[5] = double.Parse(r.Split(' ')[5]);
                string x, y;
                y = ((k0[2] * k0[3] - k0[0] * k0[5]) / (k0[1] * k0[3] - k0[0] * k0[4])).ToString();
                x = ((k0[2] - k0[1] * double.Parse(y)) / (k0[0])).ToString();
                Console.WriteLine(String.Format("{0:0.000} {1:0.000}", double.Parse(x), double.Parse(y)));
            }
        }
    }
}