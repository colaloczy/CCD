using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AOJ
{
	class Program
	{
		static void Main(string[] args)
		{
			var str = "";
			while ((str = Console.ReadLine()) != null)
			{
				var z = str.Split(' ').Select(i => int.Parse(i)).ToArray();
				double a = z[0], b = z[1], c = z[2], d = z[3], e = z[4], f = z[5];
				double y = (a * f - c * d) / (-b * d + e * a);
				double x = (c - b * y) / a;
				Console.WriteLine("{0:F3} {1:F3}", x, y);
			}
		}
	}
}