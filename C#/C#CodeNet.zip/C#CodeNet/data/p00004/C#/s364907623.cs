using System;
class Volumen0
{
    static void Main()
    {
        const int MAX_SIZE = 6;
        double[] alpha = new double[MAX_SIZE];
        string[] numal;
        string line;
        while ((line = Console.ReadLine()) != null)
        {
            numal = line.Split();
            for (int i = 0; i < 6; i++)
            {
                alpha[i] = double.Parse(numal[i]);
            }
            double y = (alpha[2] * alpha[3] - alpha[0] * alpha[5]) / (alpha[1] * alpha[3] - alpha[0] * alpha[4]);
            double x = (alpha[2] - alpha[1] * y) / alpha[0];
            Console.WriteLine("{0:f3} {1:f3}", x, y);
        }
    }
}
