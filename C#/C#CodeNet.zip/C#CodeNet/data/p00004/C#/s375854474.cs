using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Volume0004
{
    class Program
    {

        static void Main(string[] args)
        {
             string _coefficients;
            

            while ((_coefficients = Console.ReadLine()) != null)
            {
                decimal[] _arrayCoefficients = new decimal[6];
                decimal _x;
                decimal _y;
                _arrayCoefficients = _coefficients.Split(' ').Select(decimal.Parse).ToArray();
                decimal a = _arrayCoefficients[0];
                decimal b = _arrayCoefficients[1];
                decimal c = _arrayCoefficients[2];
                decimal d = _arrayCoefficients[3];
                decimal e = _arrayCoefficients[4];
                decimal f = _arrayCoefficients[5];
                _y = (c * d - a * f) / (b * d - a * e);
                _x = (c - b * _y) / a; ;
                Console.WriteLine(_x.ToString("F3") + " " + _y.ToString("F3"));
            }
        }
    }
}
