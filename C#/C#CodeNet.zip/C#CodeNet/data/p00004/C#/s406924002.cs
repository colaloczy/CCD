using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        string s;
        while (!string.IsNullOrEmpty(s = Console.ReadLine()))
        {
            var t = Array.ConvertAll(s.Split(), int.Parse);
            // 0 1 2
            // 3 4 5
            double det = t[0] * t[4] - t[1] * t[3];
            double x = (t[2] * t[4] - t[1] * t[5]) / det;
            double y = (t[0] * t[5] - t[2] * t[3]) / det;
            Console.WriteLine(x.ToString("f3") + " " + y.ToString("f3"));
        }
    }
}