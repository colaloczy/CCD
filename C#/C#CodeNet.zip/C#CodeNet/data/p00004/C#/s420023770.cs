using System;
using System.Collections.Generic;

class Program {
    static int Main(string[] args) {
        List<double[]> list = new List<double[]>();

        while (true) {
            string v = Console.ReadLine();
            if (v.Trim().Length == 0) { break; }

            string[] vs = v.Split(' ');
            double[] vd = new double[6];

            for (int i = 0; i < 6; i++) {
                vd[i] = double.Parse(vs[i]);
            }
            list.Add(vd);
        }



        return 0;
    }
}