using System;

namespace _0004
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                var input = Console.ReadLine();
                if (string.IsNullOrEmpty(input)) 
                {
                    break;
                }

                string[] inputs = input.Split(' ');
                int[] coefficients = new int[6];
                for (int i = 0; i < 6; i++)
                {
                    coefficients[i] = int.Parse(inputs[i]);
                }

                double x = (double)(coefficients[2] * coefficients[4] - coefficients[1] * coefficients[5]) / (coefficients[0] * coefficients[4] - coefficients[1] * coefficients[3]);
                double y = (double)(coefficients[0] * coefficients[5] - coefficients[2] * coefficients[3]) / (coefficients[0] * coefficients[4] - coefficients[1] * coefficients[3]);

                Console.WriteLine("{0:f3} {1:f3}", x, y);
            }
        }
    }
}