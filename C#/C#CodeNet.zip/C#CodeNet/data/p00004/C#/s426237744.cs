using System;
using System.Linq;

class SimultaneousEquation 
{
    static void Main()
    {
        var q =
            from se in 
                from p in GetProblems()
                select p.Split( ' ' ).Select( _ => double.Parse( _ ) )
            let a = se.Skip( 0 ).First()
            let b = se.Skip( 1 ).First()
            let c = se.Skip( 2 ).First()
            let d = se.Skip( 3 ).First()
            let e = se.Skip( 4 ).First()
            let f = se.Skip( 5 ).First()
            let y = ( c - f * a / d ) / ( b - e * a / d )
            let x = ( c - b * y ) / a
            select x.ToString( "0.000" ) + " " + y.ToString( "0.000" );
        foreach ( var solution in q )
            Console.WriteLine( solution );
    }

    static System.Collections.Generic.IEnumerable<string> GetProblems()
    {
        string buffer = "";
        while ( ( buffer = Console.ReadLine() ) != null )
            yield return buffer;
    }
}