using System;
using System.IO;
using System.Linq;

class Program
{
    static void Main()
    {
        string line;
        while((line = Console.ReadLine()) != null)
        {
            double[] a = line.Split(' ').Select(double.Parse).ToArray();
            double[,] m = new double[2, 2] { { a[0], a[1] }, { a[3], a[4] } };
            double[] v = new double[2] { a[2], a[5] };

            double d = m[0, 0] * m[1, 1] - m[0, 1] * m[1, 0];

            m[0, 0] /= d; m[0, 1] /= -d; m[1, 0] /= -d; m[1, 1] /= d;
            swap(ref m[0, 0], ref m[1, 1]);

            double x = m[0, 0] * v[0] + m[0, 1] * v[1];
            double y = m[1, 0] * v[0] + m[1, 1] * v[1];

            Console.WriteLine(string.Format("{0:f3} {1:f3}", x, y));
        }
    }

    static void swap(ref double a, ref double b)
    {
        double temp = a;
        a = b;
        b = temp;
    }
}