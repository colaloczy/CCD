using System;
using System.Linq;

namespace _0004
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                int[] x = Console.ReadLine().Split().Select(int.Parse).ToArray();
                int a = x[0];
                int b = x[1];
                int c = x[2];
                int d = x[3];
                int e = x[4];
                int f = x[5];
                int t, e1;
                int c1 = d / a * b;
                t = e - b;
                e1 = f - c1;
                int y = e1 / t;
                int x1 = (c - b * y) / a;
                Decimal result;
                result = Math.Round((decimal)y, 3, MidpointRounding.AwayFromZero);

                Decimal result2;
                result2 = Math.Round((decimal)x1, 3, MidpointRounding.AwayFromZero);

                Console.WriteLine("" + x1 + " " + y + "");
            }
        }
    }
}