using System;
using System.Collections.Generic;
using System.Linq;


namespace _004_Simultaneous_Equation
{
	class Program
	{
		static void Main ( string[] args )
		{
			string inputStr;

			while ((inputStr = Console.ReadLine ()) != null)
			{
				int[] tmp = inputStr.Split (' ').Select (str => int.Parse (str)).ToArray ();
				int a = tmp[0];
				int b = tmp[1];
				int c = tmp[2];
				int d = tmp[3];
				int e = tmp[4];
				int f = tmp[5];

				int divide = (a * e - b * d);
				double X = (double) (c * e - b * f) / divide;
				double Y = (double) (f * a - c * d) / divide;
				Console.WriteLine ("{0:0.000} {1:0.000}", X, Y);
			}
		}
	}
}