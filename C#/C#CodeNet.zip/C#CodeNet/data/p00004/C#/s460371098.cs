using System;

namespace AOJ
{
    class SimultaneousEquation
    {
        public static void Main()
        {
            while (true)
            {
                string input = Console.ReadLine();
                if (string.IsNullOrEmpty(input)) { break; }
                var tmp = input.Split(' ');
                int a = int.Parse(tmp[0]);
                int b = int.Parse(tmp[1]);
                int c = int.Parse(tmp[2]);
                int d = int.Parse(tmp[3]);
                int e = int.Parse(tmp[4]);
                int f = int.Parse(tmp[5]);
                decimal x = ((b * f) - (c * e)) / ((b * d) - (a * e));
                decimal y = ((c * d) - (a * f)) / ((b * d) - (a * e));

                // 小数点以下4桁目を四捨五入
                x = Math.Truncate(x * 1000 + 0.5m) / 1000;
                y = Math.Truncate(y * 1000 + 0.5m) / 1000;
                Console.WriteLine(string.Format("{0:0.000} {1:0.000}", x, y));
            }
        }
    }
}