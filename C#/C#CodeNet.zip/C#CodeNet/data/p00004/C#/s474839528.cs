using System;
class test
{
	static void Main()
	{
		string input;
		while ((input = Console.ReadLine()) != null )
		{
			int[] vv = new int[6];
			string[] ss = new string[6];
			ss = input.Split(' ');

			for ( int i=0; i<6; i++ )
			{
				vv[i] = int.Parse(ss[i]);
			}

			int detA = vv[0] * vv[4] - vv[1] * vv[3];

			float x = (vv[4] * vv[2] - vv[1] * vv[5]) / detA;
			float y = (- vv[3] * vv[2] + vv[0] * vv[5]) / detA;
			
			Console.WriteLine(x.ToString("F3") + " " + y.ToString("F3"));
		}
	}
}