using System;
class main
{
    static void Main(string[] args)
    {
    string s = Console.ReadLine();

        if (s != null)
        {
            string[] t = s.Split(' ');
            double[] u = new double[6];

            for (int i = 0; i < t.Length; ++i)
            {
                u[i] = double.Parse(t[i]);
            }

            double a0 = u[0] * u[3];
            double b0 = u[1] * u[3];
            double c0 = u[2] * u[3];
            double d0 = u[3] * u[0];
            double e0 = u[4] * u[0];
            double f0 = u[5] * u[0];

            //double a1 = a0 - d0;
            double b1 = b0 - e0;
            double c1 = c0 - f0;

            double y = c1 / b1;
            double x = (u[2] - (y * u[1])) / u[0];

            y = ToHalfAdjust(y, 3);
            x = ToHalfAdjust(x, 3);

            //Console.WriteLine("{0} : {1} : {2} : {3} : {4} : {5}", a0, b0, c0, d0, e0, f0);
            //Console.WriteLine("{0} : {1} : {2}", a1, b1, c1);
            Console.WriteLine("{0} {1}", x.ToString("f3"), y.ToString("f3"));
        }
        Console.ReadKey();
    }

    public static double ToHalfAdjust(double dValue, int iDigits)
    {
        double dCoef = System.Math.Pow(10, iDigits);

        return dValue > 0 ? System.Math.Floor((dValue * dCoef) + 0.5) / dCoef :
                            System.Math.Ceiling((dValue * dCoef) - 0.5) / dCoef;
    }
}