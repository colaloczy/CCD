using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace mondai0004
{
	class Program
	{
		static void Main(string[] args)
		{
			while( true ) {
				var	str	= Console.ReadLine();
				if( str == null ) {
					break;
				}
				var	n	= str.Split();
				var	a	= double.Parse( n[ 0 ] );
				var	b	= double.Parse( n[ 1 ] );
				var	c	= double.Parse( n[ 2 ] );
				var	d	= double.Parse( n[ 3 ] );
				var	e	= double.Parse( n[ 4 ] );
				var	f	= double.Parse( n[ 5 ] );
				double	x	= (c * e - b * f) / (a * e - b * d);
				double	y	= (c * d - a * f) / (b * d - a * e);
				Console.WriteLine( "{0:f3} {1:f3}", x, y );
			}
			
			/*while( true ) {
				var	str	= Console.ReadLine();
				if( str == null ) {
					break;
				}
				var	n	= Array.ConvertAll( str.Split(), a => double.Parse( a ) );
				
				// 加減法
				var	nn	= Array.ConvertAll( str.Split(), a => double.Parse( a ) );
				for( int i = 0; i < 3; i++ ) {
					nn[ i ]	*= n[ 3 ];
				}
				for( int i = 3; i < 6; i++ ) {
					nn[ i ]	*= n[ 0 ];
				}
				double	y	= (nn[ 2 ] - nn[ 5 ]) / (nn[ 1 ] - nn[ 4 ]);
				double	x	= (n[ 2 ] - (n[ 1 ] * y)) / n[ 0 ];
				Console.WriteLine( "{0:f3} {1:f3}", x, y );
			}*/
		}
	}
}