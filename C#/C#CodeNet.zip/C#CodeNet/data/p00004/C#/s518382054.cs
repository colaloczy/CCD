using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;

public class Equation
{
	public static void Main(string[] args)
	{
		BindingList<string> outputList = new BindingList<string>();	
		do 
		{
			string read = Console.ReadLine();
			if (string.IsNullOrEmpty(read))
			{
				break;
			}
			string[] line = read.Split(' ');
			decimal a = int.Parse(line[0]);
			decimal b = int.Parse(line[1]);
			decimal c = int.Parse(line[2]);
			decimal d = int.Parse(line[3]);
			decimal e = int.Parse(line[4]);
			decimal f = int.Parse(line[5]);
			decimal y = Math.Round((a*f-c*d)/(a*e-b*d), 3);
			decimal x = Math.Round((c-b*y)/a, 3);
			outputList.Add(x + " " + y);
		} while(true);
		foreach (string output in outputList)
		{
			Console.WriteLine(output);
		}
	}
}