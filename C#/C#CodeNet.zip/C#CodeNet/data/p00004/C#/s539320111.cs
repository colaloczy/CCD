using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v0_0004
{
    class Program
    {
        static void Main(string[] args)
        {
            string line;
            while (!string.IsNullOrEmpty(line = Console.ReadLine()))
            {
                var input = line.Split(' ');
                int a = int.Parse(input[0]);
                int d = int.Parse(input[3]);

                int b = int.Parse(input[1]) * d;
                int c = int.Parse(input[2]) * d;
                int e = int.Parse(input[4]) * a;
                int f = int.Parse(input[5]) * a;
                b -= e;
                c -= f;
                double y = Math.Round((double)c / b, 3);
                double x = Math.Round((f - y * e) / (a * d), 3);

                Console.WriteLine("{0:f3} {1:f3}", x, y);
            }
        }
    }
}