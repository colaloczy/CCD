using System;
using System.Linq;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        string s;
        while ((s = Console.ReadLine()).Length > 0)
        {
            var t = Array.ConvertAll(s.Split(), int.Parse);
            double[][] M = new double[2][];
            M[0] = new double[] { t[0], t[1], t[2] };
            M[1] = new double[] { t[3], t[4], t[5] };
            GaussianJordan(M);
            Console.WriteLine(M[0][2].ToString("f3") + " " + M[1][2].ToString("f3"));
        }
    }

    public static bool GaussianJordan(double[][] M)
    {
        const double EPS = 1e-8;
        int R = M.Length;
        int C = M[0].Length;
        Action<int, int> Swap = (r1, r2) => { var t = M[r1]; M[r1] = M[r2]; M[r2] = t; };

        for (int i = 0; i < R; i++)
        {
            int pivot = i;
            for (int k = i; k < R; k++)
                if (Math.Abs(M[k][i]) > Math.Abs(M[pivot][i]))
                    pivot = k;
            Swap(pivot, i);
            if (Math.Abs(M[i][i]) < EPS) return false;
            for (int j = i + 1; j < C; j++) M[i][j] /= M[i][i];
            M[i][i] = 1;
            for (int k = 0; k < R; k++)
                if (k != i)
                {
                    for (int j = i + 1; j < C; j++)
                        M[k][j] -= M[k][i] * M[i][j];
                    M[k][i] = 0;
                }
        }

        return true;
    }

}