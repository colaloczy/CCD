using System;
using System.Linq;

public class Program
{
    private static void Main()
    {
        string readLine;
        while (!string.IsNullOrEmpty(readLine = Console.ReadLine()))
        {
            var line = readLine.Split().Select(double.Parse).ToList();
            var a = line[0];
            var b = line[1];
            var c = line[2];
            var d = line[3];
            var e = line[4];
            var f = line[5];
            Console.WriteLine("{0:0.000} {1:0.000}", Math.Round((b * f - c * e) / (b * d - a * e), 3), Math.Round((a * f - c * d) / (a * e - b * d), 3));
        }
    }
}