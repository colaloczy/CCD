using System;

class MyClass
{
    static void Main(string[] args)
    {
        string str = "";
        while ((str = Console.ReadLine()) != null)
        {
            string[] str2 = str.Split(' ');
            int a = int.Parse(str2[0]);
            int b = int.Parse(str2[1]);
            int c = int.Parse(str2[2]);
            int d = int.Parse(str2[3]);
            int e = int.Parse(str2[4]);
            int f = int.Parse(str2[5]);
            Console.WriteLine("{0:0.000} {1:0.000}", Math.Round((double)(c * e - f * b) / (a * e - d * b), 3, MidpointRounding.AwayFromZero), Math.Round((double)(c * d - f * a) / (b * d - e * a), 3, MidpointRounding.AwayFromZero));
        }
    }
}
