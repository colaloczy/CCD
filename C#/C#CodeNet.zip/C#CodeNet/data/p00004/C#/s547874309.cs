using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P0004_SimultaneousEquation
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> lines = new List<string>();
            string readLine;

            do
            {
                readLine = Console.ReadLine();
                if (readLine != null)
                {
                    lines.Add(readLine);
                }
            }
            while (readLine != null);


            foreach (string line in lines)
            {
                List<string> coefficientsStr = line.Split(' ').ToList<string>();
                List<decimal> coefficients = new List<decimal>();

                foreach (string sideStr in coefficientsStr)
                {
                    coefficients.Add(decimal.Parse(sideStr));
                }

                decimal left = (coefficients[1] / coefficients[0]) - (coefficients[4] / coefficients[3]);
                decimal right = (coefficients[2] / coefficients[0]) - (coefficients[5] / coefficients[3]);

                decimal y = right / left;
                decimal x = (coefficients[2] / coefficients[0]) - ((coefficients[1] / coefficients[0]) * y);

                Console.WriteLine("{0:f3} {1:f3}", (x + (decimal)0.0005), (y + (decimal)0.0005));

            }

        }
    }
}