using System;

namespace v0_0004
{
    class Program
    {
        static void Main(string[] args)
        {
            string line;
            while ((line = Console.ReadLine()) != null)
            {
                var input = line.Split(' ');
                var a = double.Parse(input[0]);
                var d = double.Parse(input[3]);

                var b = double.Parse(input[1]) * d;
                var c = double.Parse(input[2]) * d;
                var e = double.Parse(input[4]) * a;
                var f = double.Parse(input[5]) * a;
                b -= e;
                c -= f;
                double y = Math.Round(c / b, 3);
                double x = Math.Round((f - y * e) / (a * d), 3);

                Console.WriteLine("{0:f3} {1:f3}", x, y);
            }
        }
    }
}