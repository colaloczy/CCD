using System;
using System.Linq;

namespace Volume0
{
    class Program
    {
        static void Main(string[] args)
        {
            string s;
            while((s = Console.ReadLine()) != null)
            {
                double[] i = s.Split(' ')
                              .Select(e => double.Parse(e))
                              .ToArray();
                var x = (i[2] * i[4] - i[1] * i[5]) 
                              / (i[0] * i[4] - i[1] * i[3]);
                var y = (i[5] * i[0] - i[2] * i[3])
                              / (i[0] * i[4] - i[3] * i[1]);
                Console.WriteLine("{0:F3} {1:F3}", x, y);
            }
        }
    }
}