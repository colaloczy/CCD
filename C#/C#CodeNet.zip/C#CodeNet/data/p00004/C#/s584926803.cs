using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

class Program
{
    static void Main(string[] args)
    {
        while (true)
        {
            var line = Console.ReadLine();
            if (string.IsNullOrEmpty(line))
            {
                break;
            }
            var vs = line.Split(' ').Select(double.Parse).ToArray();
            var v1 = vs.Take(3).Select(x => x * vs[4]).ToArray();
            var v2 = vs.Skip(3).Select(x => x * vs[1]).ToArray();
            //var xs = v1.Zip(v2, (x, y) => x - y).ToArray();
            //var xResult = xs[2] / xs[0];
            var xResult = (v1[2] - v2[2]) / (v1[0] - v2[0]);
            var yResult = (vs[2] - vs[0] * xResult) / vs[1];
            Console.WriteLine("{0:0.000} {1:0.000}", Math.Floor(xResult * 1000) / 1000, Math.Floor(yResult * 1000) / 1000);
        }
    }
}