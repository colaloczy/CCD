using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;

namespace AOJV0
{
    class P0004
    {
        static void Main()
        {
            foreach(var s in EnumerateInputs()
                            .Select(x => x.Split(' '))
                            .Select(x => x.Select(double.Parse)))
            {
                var abc = s.Take(3).ToArray();
                var def = s.Skip(3).ToArray();
                var r1 = abc.Select(d => d * def[0]).ToArray();
                var r2 = def.Select(d => d * abc[0]).ToArray();
                var y = Math.Round((r1[2] - r2[2]) / (r1[1] - r2[1]), MidpointRounding.AwayFromZero);
                var x = Math.Round((abc[2] - abc[1] * y) / abc[0], MidpointRounding.AwayFromZero);
                Console.WriteLine(string.Format("{0} {1}", x.ToString("F3"), y.ToString("F3")));
            }
        }

        static IEnumerable<string> EnumerateInputs()
        {
            while(true)
            {
                var s = Console.In.ReadLine();
                if(s == null)
                    break;
                yield return s;
            }
        }
    }
}