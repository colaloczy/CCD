using System;
 
class Program{
	public static void Main(){
		string s;
		while((s = Console.ReadLine()) != null){
			int[] n = Array.ConvertAll(s.Split(' '), int.Parse);

			float a = n[2] * n[4] - n[1] * n[5];
			float b = n[2] * n[3] - n[0] * n[5];
			float c = n[0] * n[4] - n[1] * n[3];

			Console.WriteLine("{0:f3} {1:f3}", a/c, b/c);
		}
	}
}