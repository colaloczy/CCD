using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0004
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = "";
            double[] term = new double[6];
            List<string> answer = new List<string>();
            while ((s = Console.ReadLine()) != null)
            {
                term = s.Split(' ').Select(double.Parse).ToArray();
                //0=a 1=b 2=c 3=d 4=e 5=f
                double x = 0;
                double y = 0;

                x = Math.Round((term[2] * term[4] - term[5] * term[1]) / (term[0] * term[4] - term[3] * term[1]),3,MidpointRounding.AwayFromZero);//c * e - f * b / a * e - d * b
                y = Math.Round((term[2] * term[3] - term[5] * term[0]) / (term[1] * term[3] - term[4] * term[0]),3,MidpointRounding.AwayFromZero);//c * d - f * a / b * d - e * a

                Console.WriteLine("{0:f3} {1:f3}",x,y);
            }
        }
    }
}

