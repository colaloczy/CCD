using System;
using System.Linq;

namespace AOJ0004
{
    class Program
    {
        static void Main()
        {
            string line;
            while ((line = Console.ReadLine()) != null)
            {
                var values = line.Split(' ').Select(double.Parse).ToArray();
                var x = (values[4]*values[2] - values[1]*values[5])/(values[0]*values[4] - values[1]*values[3]);
                var y = (values[0]*values[5] - values[3]*values[2])/(values[0]*values[4] - values[1]*values[3]);

                Console.WriteLine("{0:f3} {1:f3}", x, y);
            }
        }
    }
}