using System;

public class hello
{
    public static void Main()
    {
        string w;
        for (; (w = Console.ReadLine()) != null;)
        {
            string[] line = w.Trim().Split(' ');
            var a = int.Parse(line[0]);
            var b = int.Parse(line[1]);
            var c = int.Parse(line[2]);
            var d = int.Parse(line[3]);
            var e = int.Parse(line[4]);
            var f = int.Parse(line[5]);
            var x0 = (double)(c * e - b * f) / (a * e - b * d);
            var x1 = Math.Round(x0, 3, MidpointRounding.AwayFromZero);
            var y0 = (double)(a * f - c * d) / (a * e - b * d);
            var y1 = Math.Round(y0, 3, MidpointRounding.AwayFromZero);
            Console.WriteLine("{0:0.000} {1:0.000}", x1, y1);
        }
    }
}

