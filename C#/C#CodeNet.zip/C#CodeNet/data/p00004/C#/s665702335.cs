using System;
//using System.Text;
//using System.Linq;
class Program
{
    static void Main()
    {
        while (true)
        {
            string r = Console.ReadLine();
            if (r == null) break;
            double[] a = new double[6];
            for (int i = 0; i < 6; i++) a[i] = double.Parse(r.Split(' ')[i]);
            double x = (a[2] * a[3] - a[0] * a[5]) / (a[1] * a[3] - a[0] * a[4]);
            Console.WriteLine(String.Format("{0:f3} {1:f3}", (a[2] - a[1] * x) / a[0], x));
        }
    }
}