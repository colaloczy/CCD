using System;
using System.Linq;

namespace Volume0
{
    class Program
    {
        static void Main(string[] args)
        {
            while(true)
            {
                string s = Console.ReadLine();
                if (s == null) break;
                int[] i = s.Split(' ')
                            .Select(e => int.Parse(e))
                            .ToArray();
                string x = ((i[2] * i[4] - i[1] * i[5]) 
                              / (i[0] * i[4] - i[1] * i[3]))
                                  .ToString("F3");
                string y = ((i[5] * i[0] - i[2] * i[3])
                              / (i[0] * i[4] - i[3] * i[1]))
                                  .ToString("F3");
                Console.WriteLine("{0} {1}", x, y);
            }
        }
    }
}