using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace aoj
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                string[] a = new string[6];
                int d = 0;
                string k = Console.ReadLine();
                if (k == null) break;
                for (int i = 0; i <= k.Length - 1; i++)
                {
                    if (k.Substring(i, 1) == " ") d += 1;
                }
                if (d >= 5)
                {
                    if (k == null) break;
                    for (int i = 0; i <= k.Length - 1; i++)
                    {
                        if (k.Substring(i, 1) == " ") d += 1;
                        if (d == 5 && k.Substring(i, 1) != " ") a[0] = a[0] + k.Substring(i, 1);
                        if (d == 6 && k.Substring(i, 1) != " ") a[1] = a[1] + k.Substring(i, 1);
                        if (d == 7 && k.Substring(i, 1) != " ") a[2] = a[2] + k.Substring(i, 1);
                        if (d == 8 && k.Substring(i, 1) != " ") a[3] = a[3] + k.Substring(i, 1);
                        if (d == 9 && k.Substring(i, 1) != " ") a[4] = a[4] + k.Substring(i, 1);
                        if (d == 10 && k.Substring(i, 1) != " ") a[5] = a[5] + k.Substring(i, 1);
                    }
                    double[] s = new double[6];
                    s[0] = int.Parse(a[0]) * int.Parse(a[3]);
                    s[1] = int.Parse(a[1]) * int.Parse(a[3]);
                    s[2] = int.Parse(a[2]) * int.Parse(a[3]);
                    s[3] = int.Parse(a[3]) * int.Parse(a[0]);
                    s[4] = int.Parse(a[4]) * int.Parse(a[0]);
                    s[5] = int.Parse(a[5]) * int.Parse(a[0]);
                    s[1] = s[1] - s[4];
                    s[2] = s[2] - s[5];
                    s[2] = s[2] / s[1];
                    double x = 0;
                    double y = 0;
                    y = s[2];
                    x = (s[5] - s[4] * y) / s[3];
                    string xx = Math.Round(x, 3).ToString();
                    string yy = Math.Round(y, 3).ToString();
                    for (int i = 0; i <= xx.Length - 1; i++)
                    {
                        if (xx.Substring(i, 1) == ".") break;
                        if (i == xx.Length - 1) xx = xx + ".000";
                    }
                    for (int i = 0; i <= yy.Length - 1; i++)
                    {
                        if (yy.Substring(i, 1) == ".") break;
                        if (i == yy.Length - 1) yy = yy + ".000";
                    }

                    Console.WriteLine(xx + " " + yy);
                }
            }
        }
    }
}