using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace mondai0004
{
	class Program
	{
		static void Main(string[] args)
		{
			while( true ) {
				var	str	= Console.ReadLine();
				if( str == null ) {
					break;
				}
				var	n	= Array.ConvertAll( str.Split(), a => double.Parse( a ) );
				
				// 加減法
				var	n_0	= n[ 0 ];
				var	n_3	= n[ 3 ];
				for( int i = 0; i < 3; i++ ) {
					n[ i ]	*= n_3;
				}
				for( int i = 3; i < 6; i++ ) {
					n[ i ]	*= n_0;
				}
				double	y	= (n[ 2 ] - n[ 5 ]) / (n[ 1 ] - n[ 4 ]);
				double	x	= (n[ 2 ] - (n[ 1 ] * y)) / n[ 0 ];
				Console.WriteLine( "{0:f3} {1:f3}", x, y );
			}
		}
	}
}