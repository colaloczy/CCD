using System;
class test
{
	static void Main()
	{
		string input;
for ( i=0 ; i<2 ; i++ )
		{
input = Console.ReadLine();
			int[] vv = new int[6];
			string[] ss = new string[6];
			ss = input.Split(' ');

			for ( int i=0; i<6; i++ )
			{
				vv[i] = int.Parse(ss[i]);
			}

			int detA = vv[0] * vv[4] - vv[1] * vv[3];

			double x = (vv[4] * vv[2] - vv[1] * vv[5]) / detA;
			double y = (- vv[3] * vv[2] + vv[0] * vv[5]) / detA;
			
			x = Math.Round( x*1000, MidpointRounding.AwayFromZero ) / 1000;
			y = Math.Round( y*1000, MidpointRounding.AwayFromZero ) / 1000;
			Console.WriteLine("{0:F3} {1:F3}", x, y);
		}
	}
}