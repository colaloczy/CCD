using System;

public class p0004{
	p0004(){
		string str;
		string[] s;
		double[] a = new double[6];
		double r1, r2, t;
		
		while((str = Console.ReadLine()) != null){
			s = str.Split(' ');
			for(int i = 0; i < 6; ++i)
				a[i] = double.Parse(s[i]);
			t = a[0]*a[4]-a[1]*a[3];
			r1 = (a[4]*a[2]-a[1]*a[5])/t;
			r2 = (a[0]*a[5]-a[3]*a[2])/t;
			Console.WriteLine("{0} {1}", r1.ToString("f3"), r2.ToString("f3"));
		}
	}
	
	public static int Main(string[] args){
		new p0004();
		return 0;
	}
}