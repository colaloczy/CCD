using System;
using System.Collections.Generic;
using System.Linq;

namespace csharptest
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            double []x = new double[200];
            double []y = new double[200];
            while (true)
            { 
                string str = Console.ReadLine();
                if (String.IsNullOrEmpty(str) == false)
                {
                    string[] s = str.Split(' ');
                    int a = int.Parse(s[0]);
                    int b = int.Parse(s[1]);
                    int c = int.Parse(s[2]);
                    int d = int.Parse(s[3]);
                    int e = int.Parse(s[4]);
                    int f = int.Parse(s[5]);
                    y[i] = ((c / a - f / d) * a * d) / (a * d - a * e);
                    x[i] = (c - b * y[i]) / a;
                    i++;
                }
                else
                {
                    break;
                }
            }
            for (int n = 0; n < i; n++)
            {
                Console.WriteLine((Math.Floor(x[n] * 1000) / 1000) + " " + (Math.Floor(y[n] * 1000) / 1000));
            }
        }
    }
}