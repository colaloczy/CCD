using System;
using System.Collections.Generic;
using System.Linq;

namespace AOJ
{
  class Program
  {
    public static void Main(string[] args)
    {
      foreach (var co in ReadNumbers())
      {
        var det = (double)co[0] * co[4] - co[1] * co[3];
        var x = (1.0 / det) * co[4] * co[2] + (1 / det) * -co[1] * co[5];
        var y = (1.0 / det) * -co[3] * co[2] + (1 / det) * co[0] * co[5];
        Console.WriteLine("{0:F3} {1:F3}", x, y);
      }
    }

    static IEnumerable<int[]> ReadNumbers()
    {
      string line;
      while ((line = Console.ReadLine()) != null)
        yield return line.Split(' ').Select(s => int.Parse(s)).ToArray();
    }
  }
}