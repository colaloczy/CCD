using System;
using System.Collections.Generic;
using System.Linq;

namespace P0004_SimultaneousEquation
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> lines = new List<string>();
            string readLine;

            do
            {
                readLine = Console.ReadLine();
                if (readLine != null)
                {
                    lines.Add(readLine);
                }
            }
            while (readLine != null);


            foreach (string line in lines)
            {
                List<string> coefficientsStr = line.Split(' ').ToList<string>();
                List<decimal> coefficients = new List<decimal>();

                foreach (string sideStr in coefficientsStr)
                {
                    coefficients.Add(decimal.Parse(sideStr));
                }

                decimal x, y;
                
                if(coefficients[0] == 0)
                {
                    y = coefficients[2] / coefficients[1];
                    x = (coefficients[5] - (coefficients[4] * y)) / coefficients[3];
                }
                else if (coefficients[1] == 0)
                {
                    x = coefficients[2] / coefficients[0];
                    y = (coefficients[5] - (coefficients[3] * x)) / coefficients[4];
                }
                else if (coefficients[3] == 0)
                {
                    y = coefficients[5] / coefficients[4];
                    x = (coefficients[2] - (coefficients[1] * y)) / coefficients[0];
                }
                else if (coefficients[4] == 0)
                {
                    x = coefficients[5] / coefficients[3];
                    y = (coefficients[2] - (coefficients[0] * x)) / coefficients[1];
                }
                else
                {
                    decimal left = (coefficients[1] / coefficients[0]) - (coefficients[4] / coefficients[3]);
                    decimal right = (coefficients[2] / coefficients[0]) - (coefficients[5] / coefficients[3]);

                    y = right / left;
                    x = (coefficients[2] / coefficients[0]) - ((coefficients[1] / coefficients[0]) * y);

                }


                Console.WriteLine("{0:f3} {1:f3}", Math.Round(x, 3), Math.Round(y, 3));

            }

        }
    }
}