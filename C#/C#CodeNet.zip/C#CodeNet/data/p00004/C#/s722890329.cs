using System;

class Class01
{
    public static void Main(string[] args)
    {
        while (true)
        {
            double x, y;
            double[] a = new double[6];
            string s = Console.ReadLine();
            if (s == null) break;
            string[] ss = s.Split();

            for (int i = 0; i < 6; i++)
            {
                a[i] = int.Parse(ss[i]);
            }
            x = (a[1] * a[5] - a[2] * a[4]) / (a[1] * a[3] - a[0] * a[4]);
            y = (a[0] * a[5] - a[2] * a[3]) / (a[0] * a[4] - a[1] * a[3]);

            Console.WriteLine("{0:f3} {1:f3}",Math.Floor(x*1000)/1000,Math.Floor(y*1000)/1000);
        }
    }
}