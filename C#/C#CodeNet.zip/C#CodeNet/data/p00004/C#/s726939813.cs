using System;
using System.Collections.Generic;

namespace test
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			string input;
			List<string> outList = new List<string> ();
			while ((input = Console.ReadLine()) != "0") {
				string[] array = input.Split (' ');
				List<double> list = new List<double> ();
				foreach (string s in array) {
					list.Add (double.Parse(s));
				}

				double y = Math.Round((list [2] * list [3] - list [0] * list [5]) / (list [1] * list [3] - list [0] * list [4]),3,MidpointRounding.AwayFromZero);
				double x = Math.Round((list [2] * list [4] - list [1] * list [5]) / (list [0] * list [4] - list [1] * list [3]),3,MidpointRounding.AwayFromZero);
				string outString = string.Format ("{0:f3} {1:f3}", x, y);
				outList.Add (outString);

			}

			foreach (string s in outList) {
				Console.WriteLine (s);
			}

			Console.ReadKey ();
		}
	}
}