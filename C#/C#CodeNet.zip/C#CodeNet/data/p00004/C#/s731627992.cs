using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0004
{
    class Program
    {
        static void Main(string[] args)
        {
            string str ;
            List<string> answerList = new List<string>();
            while ((str = Console.ReadLine()) != null)
            {
                decimal[] number = str.Split(' ').Select(decimal.Parse).ToArray();
                decimal y = (number[3] * number[2] - number[0] * number[5]) / (number[1] * number[3] - number[0] * number[4]);
                decimal x = (number[2] - number[1] * y) / number[0];
                Math.Round(y,4);
                Math.Round(x,4);
                answerList.Add(x.ToString("F3") + " " + y.ToString("F3"));
            }
            foreach (string answer in answerList)
            {
                Console.WriteLine(answer);
            }
        }
    }
}

