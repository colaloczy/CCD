public class Hello{
	public static void Main(){
		string line = System.Console.ReadLine();
		while(line != null)
		{
			string[] n = line.Split(' ');
			decimal a = decimal.Parse(n[0]);
			decimal b = decimal.Parse(n[1]);
			decimal c = decimal.Parse(n[2]);
			decimal d = decimal.Parse(n[3]);
			decimal e = decimal.Parse(n[4]);
			decimal f = decimal.Parse(n[5]);
			
			decimal x = (c * e - b * f) / (a * e - b * d);
			decimal y = (c * d - a * f) / (a * e - b * d);
			
			System.Console.WriteLine(x.ToString("0.000") + " " y.ToString("0.000"));
			line = System.Console.ReadLine();
		}
	}
}