using System;
using System.Collections.Generic;
public class Hello{
    public static void Main(){
        string Arguments;
        decimal a,b,c,d,e,f,x,y;
        string[] SplittedArguments;
        
        while((Arguments = Console.ReadLine()) != null){
            SplittedArguments = Arguments.Split(' ');

            a = decimal.Parse(SplittedArguments[0]);
            b = decimal.Parse(SplittedArguments[1]);
            c = decimal.Parse(SplittedArguments[2]);
            d = decimal.Parse(SplittedArguments[3]);
            e = decimal.Parse(SplittedArguments[4]);
            f = decimal.Parse(SplittedArguments[5]);
            
            y = (decimal)(c * d - a * f) / (b * d - a * e);
            x = (decimal)(c - b * y) / a;
            
            Console.WriteLine(Math.Round(x, 3) + " " + Math.Round(y, 3));
        }
    }
}