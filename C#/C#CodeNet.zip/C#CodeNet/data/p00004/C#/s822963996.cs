using System;
using System.Collections.Generic;
using System.Linq;


namespace _004_Simultaneous_Equation
{
	class Program
	{
		static void Main ( string[] args )
		{
			string inputStr;

			while ((inputStr = Console.ReadLine ()) != null)
			{
				IEnumerable<int> tmp = inputStr.Split (' ').Select (str => int.Parse (str));
				int[] expression = tmp.Take (3).ToArray ();
				int[] expression2 = tmp.Skip (3).ToArray ();

				//2?????????X??????????????????
				int a = expression[0];
				int d = expression2[0];

				expression = expression.Select (item => item * d).ToArray ();
				expression2 = expression2.Select (item => item * a).ToArray ();

				int member = expression[1] - expression2[1];		//b??????e????????? = A
				int member2 = expression[2] - expression2[2];		//c??????f????????? = B

				//B/A?????????y????±???????
				double y = 0;
				if (member != 0)
				{
					y = (double) member2 / member;
				}

				//1?????????y?????£??\??????x????±???????

				double x = (expression[2] - expression[1] * y) / expression[0];

				Console.WriteLine ("{0:0.000} {1:0.000}", x, y);
			}
		}
	}
}