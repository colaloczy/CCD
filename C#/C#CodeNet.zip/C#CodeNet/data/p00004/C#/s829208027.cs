using System;
public class Hello{
    public static void Main(){
        string line;
        while((line=Console.ReadLine()) !=null){///// repeat unless no input
            coreProcess(line);
        }
    }
    
    public static void coreProcess(string line){
        string [] input=line.Split(' ');
        double a=int.Parse(input[0]);
        double b=int.Parse(input[1]);
        double c=int.Parse(input[2]);
        double d=int.Parse(input[3]);
        double e=int.Parse(input[4]);
        double f=int.Parse(input[5]);
        
        double y=(a*f-d*c)/(a*e-d*b);
        double x=(c-b*y)/a;
        System.Console.WriteLine("{0:f3} {1:f3}",x, y);
    }
    
}