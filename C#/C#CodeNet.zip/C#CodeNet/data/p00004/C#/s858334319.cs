using System;
using System.Collections.Generic;
using System.Linq;

class Program {
    static string ReadLine() { return Console.ReadLine(); }
    static int ReadInt() { return int.Parse(ReadLine()); }
    static int[] ReadInts() { return ReadLine().Split().Select(int.Parse).ToArray(); }
    static string[] ReadStrings() { return ReadLine().Split(); }

    // ax + by = c
    // dx + ey = f
    static void Calc(float a, float b, float c, float d, float e, float f) {
        var deno = a * e - b * d;

        var x = (c * e - b * f) / deno;
        var y = (a * f - c * d) / deno;
        Console.WriteLine("{0:f3} {1:f3}", x, y);
    }

    static void Main() {
        string s;
        while ((s = ReadLine()) != null) {
            var xs = s.Split().Select(int.Parse).ToArray();
            Calc(xs[0], xs[1], xs[2], xs[3], xs[4], xs[5]);
        }
    }
}