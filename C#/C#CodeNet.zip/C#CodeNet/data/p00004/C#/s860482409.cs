using System; 
using System.Linq;  
using System.Collections.Generic;
using System.Text;

namespace AOJ
{
  class Program
  {
    static void Main(string[] args)
    {
      var str="";
      while((str = Console.ReadLine()) != null){
      var z = str.Split(' ').Select( i => int.Parse(i)).ToArray();  
      double a = z[0],b = z[1],c = z[2],d = z[3],e = z[4],f = z[5]; 
      double y = (d*c - a*f)*1.000/(d*b - a*e);
      double x = (c - b*y)*1.000/a;
      Console.WriteLine("{0:F3} {1:F3}",x,y);
      }
    }
  }
}