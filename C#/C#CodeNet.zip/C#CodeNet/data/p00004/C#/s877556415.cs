using System;
    class Program
    {
        static void Main(string[] args)
        {
            double[] x = new double[1000];
            double[] y = new double[1000];
            int count=-1;
            string str = Console.ReadLine();
            while (!string.IsNullOrEmpty(str))
            {
                count++;
                string[] s = str.Split(' ');
                double a = double.Parse(s[0]);
                double b = double.Parse(s[1]);
                double c = double.Parse(s[2]);
                double d = double.Parse(s[3]);
                double e = double.Parse(s[4]);
                double f = double.Parse(s[5]);
                y[count] = (c * d - a * f) / (b * d - a * e);
                x[count] = (c - b * y[count]) / a;
                str = Console.ReadLine();
            }
            for (int n = 0; n <= count; n++)
                Console.WriteLine(string.Format("{0:0.000}",x[n])+" "+string.Format("{0:0.000}",y[n]));
        }
    }