using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace ConsoleApplication32
{
    class Program
    {  
      static void Main()
      {
		  var a = Console.ReadLine().Split().Select(double.Parse).ToArray();
		  double c,d,e,f;
		  c=d=e=f=0;
		  c+=(a[3]/a[0])*a[4];
		  d+=(a[3]/a[0])*a[5];
		  e+=(d-a[2])/(a[1]-c);
		  f+=(a[2]-e*a[1])/a[0];
		  e+=e*999;
		  f+=f*999;
		  f= Math.Round(f,MidpointRounding.AwayFromZero);
		  e= Math.Round(e,MidpointRounding.AwayFromZero);
		  e=e/1000;
		  f=f/1000;
		   Console.WriteLine("{0} {1}",f,e);
       }
	 }
 }