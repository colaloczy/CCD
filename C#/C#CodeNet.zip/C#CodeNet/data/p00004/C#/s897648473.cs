using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Main
    {
        static void Main(string[] args)
        {
            while (true)
            {
                double x, y;
                double[] h = new double[6];
                String str = Console.ReadLine();
                if (str == null) break;
                string[] s = str.Split();
                for (int i = 0; i < 6; i++)
                {
                    h[i] = double.Parse(s[i]);
               
                x = ((h[2] * h[4]) - (h[1] * h[5])) / ((h[0] * h[4]) - (h[1] * h[3]));
                y = ((h[2] * h[3]) - (h[0] * h[5])) / ((h[3] * h[1]) - (h[0] * h[4]));
                x = Math.Floor(x * 1000) / 1000;
                y = Math.Floor(y * 1000) / 1000;
                Console.WriteLine("{0:0.000} {1:0.000}", x, y);

            }
        }
    }
}