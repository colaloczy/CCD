using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Calc calc = new Calc();

            List<int> input = new List<int>();
            List<List<double>> ans = new List<List<double>>();
            string str;

            while (!((str = Console.ReadLine()) == null))
            {
                input = str.Split(' ').Select(int.Parse).ToList();

                ans.Add(calc.Solve(input));
            }

            for (int i = 0; i < ans.Count(); i++)
            {
                Console.WriteLine("{0:F3} {1:F3}", ans[i][0], ans[i][1]);
            }
        }
    }

    class Calc
    {
        internal List<double> Solve(List<int> input)
        {
            int a, b, c, d, e, f;
            List<List<int>> mat_A;
            List<List<double>> mat_A_1;
            List<int> vector;
            List<double> x_y;
            double num;
            int det;

            a = input[0];    b = input[1];    c = input[2];
            d = input[3];    e = input[4];    f = input[5];

            vector = new List<int>() {
                {c}, {f}
            };

            mat_A = new List<List<int>>() {
                new List<int>{ a, b },
                new List<int>{ d, e }
            };

            det = mat_A[0][0] * mat_A[1][1] - mat_A[0][1] * mat_A[1][0];

            mat_A_1 = new List<List<double>>() {
                new List<double>(){ mat_A[1][1], (-1.0) * mat_A[0][1]},
                new List<double>(){ (-1.0) * mat_A[1][0], mat_A[0][0]}
            };

            x_y = new List<double>();
            
            for (int i = 0; i < mat_A_1.Count(); i++)
            {
                num = 0;
                for (int j = 0; j < vector.Count(); j++)
                {
                    num += mat_A_1[i][j] * (double)vector[j]; 
                }
                x_y.Add(num / (double)det);
            }

            return x_y;
        }
        
    }
}

