using System;


class AOJ
{

    public static void Main()
    {

        while (true)
        {
            string ss = Console.ReadLine();
            if (ss == null) break;

            string[] s = ss.Split(' ');

            int[] a = new int[6];

            for (int i = 0; i < 6; i++)
            {
                a[i] = int.Parse(s[i]);
            }

            double x = (double)(a[2] * a[4] - a[1] * a[5]) / (a[0] * a[4] - a[1] * a[3]);

            double y = (double)(a[0] * a[5] - a[2] * a[3]) / (a[0] * a[4] - a[1] * a[3]);

            Console.WriteLine("{0:f3} {1:f3}", x, y);
        }
    }
}