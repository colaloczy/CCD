using System;
using System.Linq;

namespace Test06
{
	class MainClass
	{
		public static void Main(string[] args)
		{
			string str;
			while ((str=Console.ReadLine()) != null)
			{
				double [] nums = str.Split().Select(double.Parse).ToArray();
				var par = nums[0] / nums[3];
				nums[3] = nums[3] * par;
				nums[4] = nums[4] * par;
				nums[5] = nums[5] * par;
				var y = (nums[2] - nums[5]) / (nums[1] - nums[4]);
				var x = (nums[2] - nums[1] * y) / nums[0];

				Console.WriteLine("{0:F3} {1:F3}", x, y);
			}

		}

	}
}