using System;
using System.Collections.Generic;
using System.Linq;


namespace AOJ0004
{
    class Program
    {
        private static void Main(string[] args)
        {
            for (;;)
            {

                var s = Console.ReadLine();
                if (string.IsNullOrEmpty(s)) break;
                
                var ss = s.Split(' ');

                var q = ss.Select(Convert.ToDouble);
                double a = q.ElementAt(0);
                double b = q.ElementAt(1);
                double c = q.ElementAt(2);
                double d = q.ElementAt(3);
                double e = q.ElementAt(4);
                double f = q.ElementAt(5);

                // 2 -1 -3 1 -1 -3
                //0 3
                double x = (e*c - b*f)/(a*e - b*d);
                double y = (f - d*x)/e;
                Console.WriteLine("{0} {1}",x.ToString("0.000"),y.ToString("0.000"));


            }
        }
    }
}