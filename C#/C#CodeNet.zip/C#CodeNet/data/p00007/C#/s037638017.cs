using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Diagnostics;

namespace test
{

    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            double debt = 100000;
            for (int i = 0; i < n; i++)
            {
                debt *= 1.05;
                if (debt % 1000 != 0)
                {
                    debt = debt - (debt % 1000) + 1000;
                }
            }

            Console.WriteLine(debt);

        }


    }
        
}