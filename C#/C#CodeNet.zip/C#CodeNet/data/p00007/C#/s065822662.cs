using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0007
{
    class Program
    {
        static void Main(string[] args)
        {
            // 10万円の借金に対し1週間ごとに5%の利子が発生し1000円未満を切り上げるとき、n週間後の残高を出力するプログラム

            int n = int.Parse(Console.ReadLine());
            double balance=100000;
            for (int i = 0; i < n; i++)
            {
                double insert = (Math.Ceiling((balance * 0.05)/1000))*1000;
                balance += insert;
            }
            Console.WriteLine(balance);
        }
    }
}

