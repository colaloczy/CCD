using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Contest
{
    class Program
    {
        static int Main(string[] args)
        {
            new Program().Process();

            return 0;
        }

        private CommonInput cin;

        private void Process()
        {
            this.cin = new CommonInput();

            int money, n;

            money = 100000;

            n = this.cin.GetNextToInt();

            Console.WriteLine("{0}", this.Calc(money, n));

            Console.ReadKey();
        }

        private int Calc(int x, int n)
        {
            int y = (int)(x * 1.05);

            if (n == 0)
                return x;
            else
                return this.Calc(y / 1000 * 1000 + (y % 1000 == 0 ? 0 : 1000), n - 1);
        }
    }

    public class CommonInput
    {
        public CommonInput()
        {
            this._s = new string[0];
            this._i = 0;
        }

        public string Line { get; set; }
        private string[] _s;
        private int _i;
        private char[] _sep = { ' ' };

        public void GetLine()
        {
            this._i = 0;
            do
            {
                this.Line = Console.ReadLine();
            } while (this.Line == "");

            if (this.Line != null)
                this._s = this.Line.Split(this._sep, StringSplitOptions.RemoveEmptyEntries);
        }

        public string GetNext()
        {
            if (this._i < this._s.Length)
                return this._s[this._i++];

            this.GetLine();

            return this._s[this._i++];
        }

        public int GetNextToInt()
        {
            return int.Parse(this.GetNext());
        }

        public long GetNextToLong()
        {
            return long.Parse(this.GetNext());
        }

        public double GetNextToDouble()
        {
            return double.Parse(this.GetNext());
        }
    }
}