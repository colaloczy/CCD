using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ConsoleApplication2 {
    class Program {
        static void Main(string[] args) {

            TextReader input = Console.In;

            string str = input.ReadLine();

            int week = 0;
            if (!int.TryParse(str, out week)) {
                return;
            }

            decimal start = 100;

            for (int ii = 0; ii < week; ii++) {
                start *= 1.05m;
                // 切り上げ
                start = Math.Ceiling(start);
            }
            Console.WriteLine(start * 1000m);
        }
    }
}