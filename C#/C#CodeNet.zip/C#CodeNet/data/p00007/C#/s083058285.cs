using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            int b = int.Parse(Console.ReadLine());
            double d = 0, c = 100000, f = 0,a=0;
            for (int e = 0; e < b; e++)
            {
                a += c * 1.05d;
                d += a / 1000d;
                f = Math.Ceiling(d);
                c -= c;
                c += f * 1000;
                d -= d;
                f -= f;
                a -= a;
            }
            Console.WriteLine(c);
        }
    }
}