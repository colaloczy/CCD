using System;

class AOJ{
  static void Main()
  {
    double ans = 100000;
    int n = int.Parse(Console.ReadLine());

    for (int i = 0; i < n; i++)
      ans = Math.Ceiling(ans * 1.05 / 1000) * 1000;

    Console.WriteLine(ans);
  }
}