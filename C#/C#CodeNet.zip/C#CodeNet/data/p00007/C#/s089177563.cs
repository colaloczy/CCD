using System;

namespace _0007
{
    class Program
    {
        static void Main(string[] args)
        {
            double debt = 100000;
            var appointedWeek = int.Parse(Console.ReadLine());

            for (int weekCount = 0; weekCount< appointedWeek; weekCount++)
            {
                debt = debt * (1.05);
                if ((debt % 1000) != 0 )
                {
                    debt = debt - (debt % 1000) + 1000;
                }
            }
            Console.Write(debt);
        }
    }
}