using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace mondai0007
{
	class Program
	{
		static void Main(string[] args)
		{
			var	n	= int.Parse( Console.ReadLine() );

			long	money	= 100000;
			for( int i = 0; i < n; i++ ) {
				money	= (long)((double)money * 1.05);
				money	+= 999;
				money	= (money / 1000) * 1000;
			}
			Console.WriteLine( money );
		}
	}
}