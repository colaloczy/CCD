using System;
using System.Text;

namespace _0005 {

	public static class Program {

		public static void Main() {
			var week = int.Parse(Console.ReadLine());
			var money = 100000d;
			for (int i = 0; i < week; i++) {
				money *= 1.05;

				int x = (int) (money % 1000);
				if (x > 0) {
					money = money - x + 1000;
				}
			}
			Console.WriteLine(money);
		}

	}

}