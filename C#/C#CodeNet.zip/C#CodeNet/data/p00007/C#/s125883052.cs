using System;
class Program
    {
        static void Main(string[] args)
        {
            short n = short.Parse(Console.ReadLine());
            long x = 100000;
            for (short i = 0; i < n; i++)
            {
                x = (long)Math.Ceiling(1.05 * x/1000)*1000;
            }
            Console.WriteLine(x);
            Console.ReadLine();
        }
    }