using System;

namespace _0007
{
    class Program
    {
        static void Main(string[] args)
        {
            int A = 100000;
            Int32 a = int.Parse(Console.ReadLine());
            for (int i = 0; i < a; i++)
            {
                A = A / 20 *21;
                if (A % 1000 != 0) { A = (((int)A / 1000) + 1) * 1000; }
            }
            if (A % 1000 == 0) { Console.WriteLine(A); }
            else
            {
                Console.WriteLine(A);
            }
        }
    }
}