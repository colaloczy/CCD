using System;
using System.Linq;

class DebtHell 
{
    static void Main()
    {
        var debt = 100000m;
        var q =
            from _ in Enumerable.Range( 0, int.Parse( Console.ReadLine() ) )
            select debt = Math.Ceiling( debt * 0.00105m ) * 1000;
        Console.WriteLine( q.Last() );
    }
  
}