using System;

namespace _0007
{
    class Program
    {
        static void Main(string[] args)
        {
         float A = 100000;
            Int32 a = int.Parse(Console.ReadLine());
            for (int i = 0; i < a; i++)
            {
                A = A * (float)1.05;
            }
            if (A % 1000 == 0) { Console.WriteLine(A); }
            else
            {
                Console.WriteLine((((int)A / 1000)+1) * 1000);
            }
        }
    }
}