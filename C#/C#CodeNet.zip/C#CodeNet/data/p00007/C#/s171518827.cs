using System;
using System.Collections;
using System.Collections.Generic;

class Myon
{
    public Myon() { }
    public static int Main()
    {
        new Myon().calc();
        return 0;
    }

    void calc()
    {
        int n = int.Parse(Console.ReadLine());
        long money = 100000;
        for (int i = 0; i < n; i++)
        {
            money *= 105;
            if (money % 100000 != 0) money += 100000 - money % 100000;
            money /= 100;
        }
        Console.WriteLine(money);
    }
}