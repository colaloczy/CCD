using System;
using System.Linq;

namespace AOJ
{
	class Program
	{
		public static void Main(string[] args)
		{
			double m = 100000;
			foreach(var i in Enumerable.Range(1, int.Parse(Console.ReadLine())))
			{
				m *= 1.05;
				m = (double)Math.Ceiling((decimal)m / 1000) * 1000;
			}
			Console.WriteLine(m);
		}
	}
}