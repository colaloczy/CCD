using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0007
{
    class Program
    {
        static void Main(string[] args)
        {
            double rates = 1.05;
            double currentDept = 100000;
            double n = double.Parse(Console.ReadLine());
            for (double i = 0; i < n; ++i)
            {
                currentDept = currentDept * rates;
                double db = System.Math.Pow(10, -3);
                currentDept = System.Math.Ceiling(currentDept * db) / db;
            }
           
            Console.WriteLine(currentDept);
        }
    }
}

