using System;
class main
{
    static void Main(String[] args)
    {
        double n = double.Parse(Console.ReadLine());
        double b = 100000;
        for (int i = 0; i < n; i++)
        {
            b = b * 1.05;
            b = (Math.Ceiling(b / 1000))*1000;
        }
        Console.WriteLine(b);
    }
}