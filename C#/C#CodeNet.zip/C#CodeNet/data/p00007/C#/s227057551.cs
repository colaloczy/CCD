using System;
using System.Linq;

namespace AOJ
{
	class Program
	{
		public static void Main(string[] args)
		{
			decimal m = 100000;
			foreach(var i in Enumerable.Range(1, int.Parse(Console.ReadLine())))
			{
				m *= 1.05m;
				m = Math.Ceiling(m / 1000) * 1000;
			}
			Console.WriteLine(m);
		}
	}
}