using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp10
{
    class Program
    {
        static void Main(string[] args)
        {
            Calc calc = new Calc();

            string week = Console.ReadLine();
            int n, debt;

            n = int.Parse(week);
            debt = 100000;
   

            for (int i = 0; i < n; i++)
            {
                debt = calc.Interest(debt); 
            }

            Console.WriteLine(debt);
        }
    }

    class Calc
    {
        internal int Interest(int debt)
        {
            double interest = 1.05;
            int round_up = 1000;

            int debt2 = (int)(debt * interest);
            decimal ceiling = Math.Ceiling((decimal) debt2 / (decimal)round_up);
            debt = (int)ceiling * round_up;

            return debt;
        }


    }
}
