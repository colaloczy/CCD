using System;
    public class Test
    {
        static void Main(string[] args)
        {
            double money = 100000;
            int answer = 0;
            int n =  int.Parse(Console.ReadLine().Trim());
            for (int i = 0; i < n; i++)
            {
                answer = (int)Math.Ceiling(money*1.05 / 1000) * 1000;
                money = answer;
            }
            Console.WriteLine(money);
        }
    }
