using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication6
{
    class DebtHell
    {
        static void Main(string[] args)
        {
            int n = Int32.Parse(System.Console.ReadLine());
            double tmp = 0;
            int zandaka = 100000;

            for (int i = 0; i < n;i++ )
            {
                tmp = 1.0 * zandaka * 1.05;
                if(tmp % 1000 != 0)
                {
                    tmp = (int)(tmp / 1000) * 1000 + 1000;
                }
                zandaka = (int)tmp;
            }
            System.Console.WriteLine(zandaka);
        }
    }
}