using System;
class Program
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        double money = 1000;
        for (int i = 0;i < n; i++)
        {
            money = Math.Ceiling(money * 1.05);
        }
        Console.WriteLine(money*1000);
    }
}