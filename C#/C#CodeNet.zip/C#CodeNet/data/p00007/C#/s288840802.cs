using System;

public class Hello{
    public static void Main(){
        decimal CurrentDebt = Consts.DEBT;
        int Weeks = int.Parse(Console.ReadLine());
        for(int i = 0; i < Weeks; i++){
            CurrentDebt = Math.Ceiling(CurrentDebt * Consts.INTEREST);
        }
        Console.WriteLine(CurrentDebt * Consts.BASE);
    }
}

public static class Consts{
    public const decimal BASE = 1000m;
    public const decimal DEBT = 100m;
    public const decimal INTEREST = 1.05m;
}