using System;
public class Example {
    public static void Main() {
        int debt = 100;
        int month = int.Parse(Console.ReadLine());
        for (int i = 0; i < month; i++) {
            debt = (int)Math.Ceiling(debt*1.05);
        }
        Console.WriteLine(debt*1000);
    }
}