using System;
namespace ConsoleApplication1{
    class Program{
        static void Main(string[] args){
            int n = int.Parse(Console.ReadLine());
            double debt = 100000;
            for (int i = 0; i < n; i++) {
                debt +=debt * 0.05;
                debt = Math.Ceiling(debt/1000)*1000;
            }
            Console.WriteLine((int)debt);
        }
    }
}