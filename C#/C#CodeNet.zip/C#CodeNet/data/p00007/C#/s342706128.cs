using System;

public class hello
{
    public static void Main()
    {
        var g = 100000;
        var n = int.Parse(Console.ReadLine().Trim());
        var a = 1.05;
        var ans = g * Math.Pow(a, n);
        var ans2 = Math.Ceiling(ans / 10000) * 10000;
        Console.WriteLine(ans2);
    }
}