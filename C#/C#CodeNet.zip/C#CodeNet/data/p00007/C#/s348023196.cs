using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            double money = 100000;

            for (int i = n; i > 0; i--)
            {
                money *= 1.05d;

                money = Math.Ceiling(money / 1000) * 1000;
            }
            Console.WriteLine(money);
        }
    }
}