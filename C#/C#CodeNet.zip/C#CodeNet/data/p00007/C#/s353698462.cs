using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static string InputPattern = "Input3";

    static List<string> GetInputList()
    {
        var WillReturn = new List<string>();

        if (InputPattern == "Input1") {
            WillReturn.Add("5");
        }
        else if (InputPattern == "Input2") {
            WillReturn.Add("100");
        }
        else {
            string wkStr;
            while ((wkStr = Console.ReadLine()) != null) WillReturn.Add(wkStr);
        }
        return WillReturn;
    }

    static void Main()
    {
        List<string> InputList = GetInputList();
        int N = int.Parse(InputList[0]);

        decimal Val = 100000 / 1000;
        for (int I = 1; I <= N; I++) {
            Val = Math.Ceiling(Val * 1.05M);
        }
        Console.WriteLine(Val * 1000);
    }
}