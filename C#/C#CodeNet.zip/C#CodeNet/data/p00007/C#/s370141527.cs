using System;

class Program{
	static void Main(){
		int n = int.Parse(Console.ReadLine());
		double a = 100;

		while(n-- > 0){
			a = Math.Ceiling(a * 1.05);
		}

		Console.WriteLine((int)a * 1000);
	}
}