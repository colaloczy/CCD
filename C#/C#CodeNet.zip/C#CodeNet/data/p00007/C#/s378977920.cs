using System;

public class DebtHell
{
	public static void Main(string[] args)
	{
		int week = int.Parse(Console.ReadLine());
		double cache = 100000;
		for (int i = 0; i < week; i++)
		{
			cache *= 1.05;
			uint tempCache = (uint)cache;
			cache = tempCache;
		}
		cache += 9000;
		string temp = cache.ToString();
		Console.WriteLine(uint.Parse((temp.Substring(0, temp.Length - 4) + "0000")));
	}
}