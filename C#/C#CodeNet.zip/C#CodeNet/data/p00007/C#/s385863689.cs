using System;

namespace DebtHell
{
    class Program
    {
        static void Main(string[] args)
        {
            int input = int.Parse(Console.ReadLine());
            double SumMoney = 100000;
            for (int i = 0; i < input; i++)
            {
                SumMoney *= 1.05;
                SumMoney = Math.Ceiling(SumMoney / 1000) * 1000;
            }
            
            Console.WriteLine(SumMoney);
            Console.Read();
        }
    }
}

