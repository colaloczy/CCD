using System;


class AOJ
{

    public static void Main()
    {
        int n = int.Parse(Console.ReadLine());
        double debt = 100000;

        for(int i=0; i<n; i++){
            debt *= 1.05;
            if (debt % 1000 != 0)
            debt = ((int)debt / 1000)*1000 + 1000;
        }
        Console.WriteLine(debt);
        
    }
}
        
       