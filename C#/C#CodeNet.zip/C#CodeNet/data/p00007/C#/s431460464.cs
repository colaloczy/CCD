using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

public class Program
{

    public void Proc()
    {
        long current = 100000;

        int weekCount = int.Parse(Reader.ReadLine());

        for (int i = 0; i < weekCount; i++) {
            current = (long)(current * 1.05);
            if(current%1000>0) {
                current = (current / 1000 + 1) * 1000;
            }
        }
        Console.WriteLine(current);
    }


    public class Reader
	{
		private static StringReader sr;
		public static bool IsDebug = false;
		public static string ReadLine()
		{
			if (IsDebug)
			{
				if (sr == null)
				{
					sr = new StringReader(InputText.Trim());
				}
				return sr.ReadLine();
			}
			else
			{
				return Console.ReadLine();
			}
		}
		private static string InputText = @"



5


";
	}

	public static void Main(string[] args)
	{
#if DEBUG
		Reader.IsDebug = true;
#endif
		Program prg = new Program();
		prg.Proc();
	}
}