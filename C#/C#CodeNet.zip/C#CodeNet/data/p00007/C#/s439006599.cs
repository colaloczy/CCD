using System;

class Program
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());

        double d = 100000;
        for (int i = 0; i < n; i++)
        {
            d = Math.Ceiling(d * 1.05 / 1000) * 1000;
        }

        Console.WriteLine(d);
    }
}