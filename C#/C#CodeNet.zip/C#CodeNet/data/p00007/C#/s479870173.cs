using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AOJ
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            double m = 100000;
            for (int i = 0; i < n; i++)
            {
                m = m * 1.05;
                if (m % 1000 != 0)
                {
                    m = (int)m / 1000 * 1000 + 1000;
                }
            }
            Console.WriteLine(m);
        }
    }
}