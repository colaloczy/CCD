using System;
using System.Collections.Generic;
using System.Text;

namespace mondai0007
{
    class Program
    {
        static double rishi = 0.05;

        static int Main(string[] args)
        {
            double gankin = 100000;
            double input = double.Parse(Console.ReadLine());

            for (int i = 0; i < input; i++)
            {
                gankin = syakkin(gankin);
            }

            Console.Write(kiriage(gankin).ToString());

            return 0;
        }

        private static double syakkin(double gankin)
        {
            return gankin + (gankin * rishi);
        }

        private static int kiriage(double gankin)
        {
            return (int)Math.Ceiling(gankin / 10000) * 10000;
        }

    }
}