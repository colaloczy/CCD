using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Debt_Hell
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            double temp = 100000;

            for (int i = 0; i < n; ++i)
            {
                temp *= 1.05;
                if (temp % 1000 != 0)
                {
                    temp = ((Math.Ceiling(temp / 1000))) * 1000;
                    
                }

            }

            Console.WriteLine(temp);
        }
    }
}

