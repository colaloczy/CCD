using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0007
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            double answer = 100;
            for (int i = 0; i < n; i++)
            {
                answer = Math.Ceiling(answer * 1.05);
            }
            Console.WriteLine(answer*1000);
        }
    }
}

