using System;

namespace Volume0_0007
{
	class Program
	{
		static void Main(string[] args)
		{
			int n = int.Parse(Console.ReadLine());
			long m = 100000;

			for(int i = 0; i < n; i++) {
				double d = m * 1.05;

				m = (long)Math.Ceiling(d / 1000.0) * 1000;
			}

			Console.WriteLine(m);
		}
	}
}

