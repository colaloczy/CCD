using System;

class main
{
    static void Main(String[] args)
    {
        double n = double.Parse(Console.ReadLine());
        double b = 100000;
        b = Math.Ceiling((b * Math.Pow(1.05, n))/10000);
        Console.WriteLine(b*10000);        
    }
}