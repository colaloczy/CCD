using System;

class Program
{
    static void Main()
    {
        int d = 100000;
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            d = (int)Math.Ceiling(d * 1.05 / 1000) * 1000;
        }
        Console.WriteLine(d);
    }
}