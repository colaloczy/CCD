using System;

namespace AOJ0007
{
    class Program
    {
        static void Main()
        {
            var money = 100000L;
            var weeks = int.Parse((Console.ReadLine() ?? ""));

            for (var i = 0; i < weeks; i++)
            {
                money = (long) Math.Ceiling(money*1.05/1000)*1000;
            }

            Console.WriteLine(money);
        }
    }
}