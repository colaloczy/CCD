using System;
using System.Collections.Generic;
using System.Linq;

class Program {

    static int Main(string[] args) {
        int n = int.Parse(Console.ReadLine());

        double v = 100000;
        for (int i = 0; i < n; i++) {
            v += v * 0.05;
        }

        Console.WriteLine("{0}", Math.Ceiling(v / 10000.0f) * 10000.0f);

        return 0;
    }

    static decimal GetMinBaisu(List<decimal> a, List<decimal> b) {
        decimal v = 1;
        for (int i = 0; i < a.Count; i++) {
            v *= a[i];
        }
        for (int i = 0; i < b.Count; i++) {
            v *= b[i];
        }
        return v;
    }

    static decimal GetMaxYakusu(List<decimal> a, List<decimal> b) {
        decimal v = 1;

        for (int i = 0; i < a.Count; i++) {
            if (b.Contains(a[i]) == true) {
                v *= a[i];
                b.Remove(a[i]);
            }
        }

        return v;
    }

    static List<decimal> GetYakusu(decimal v) {
        List<decimal> list = new List<decimal>();

        decimal c = 2;
        while (true) {
            if (v < 2) { break; }

            if (v % c == 0) {
                list.Add(c);
                v = v / c;
            }
            else {
                c++;
            }
        }

        return list;
    }

    static int InputN() {
        string v = Console.ReadLine();
        return int.Parse(v);
    }

    static int[] InputInt() {
        string v = Console.ReadLine();
        string[] vs = v.Split(' ');

        return new int[] { int.Parse(vs[0]), int.Parse(vs[1]) };
    }

    static void Check(int n, List<int[]> list) {
        SortedDictionary<int, int> v = new SortedDictionary<int, int>();

        int maxValue = 0;
        for (int i = 0; i < list.Count; i++) {
            int id = list[i][0];
            if (v.ContainsKey(id) == false) {
                v.Add(id, 0);
            }

            v[id] += list[i][1];

            if (maxValue < v[id]) {
                maxValue = v[id];
                Console.WriteLine("{0} {1}", id, maxValue);
            }
            else {
                maxValue = v.Values.Max();
                var q = v.Where((x) => x.Value == maxValue);
                foreach (var item in q) {
                    Console.WriteLine("{0} {1}", item.Key, maxValue);
                    break;
                }
            }
        }
    }
}