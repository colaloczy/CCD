using System;
class _0007
{
    public static void Main()
    {
        double money = 100000;
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            money += money * 0.05;
            money = Math.Ceiling(money / 1000.0) * 1000.0;
            Console.WriteLine(money);
        }
    }
}