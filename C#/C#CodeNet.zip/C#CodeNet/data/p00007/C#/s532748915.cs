using System;
namespace _0007
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int syakkin = 100000;
            for(int i=0;i<n;i++)
            {
                syakkin = syakkin / 20 * 21;
                if(syakkin%1000!=0)
                {
                    syakkin = (syakkin / 1000 + 1) * 1000;
                }
            }
            Console.WriteLine(syakkin);
            Console.ReadLine();
        }
    }
}