using System;

class main
{
    static void Main(String[] args)
    {
        int n = int.Parse(Console.ReadLine());
        double b = 100000;
        for (int i = 0; i < n; i++)
        {
            b = b * 1.05;
            b += 999;
            b = ((int)(b / 1000)*1000);
        }
        Console.WriteLine(b);
        Console.ReadKey();
    }
}