using System;

namespace v0_0007
{
    class Program
    {
        static void Main(string[] args)
        {
            var week = int.Parse(Console.ReadLine());
            decimal debt = 100000M;
            for (int i = 0; i < week; i++)
            {
                debt *= 1.05M;
                var rem = debt % 1000;
                debt = debt - rem + ((rem > 0) ? 1000 : 0);
            }
            Console.WriteLine("{0:f0}", debt);
        }
    }
}