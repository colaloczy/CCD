using System;

namespace AOJ
{
    public class _007
    {
        public static void Main (string[] args)
        {
            float a = 100000;
            var l = int.Parse (Console.ReadLine ());
            for (int i = 0; i < l; ++i) {
                a *= 1.05f;
                if (a % 1000 != 0)
                    a += 1000 - a % 1000;
            }
            Console.WriteLine ((int)a);
        }
    }
}