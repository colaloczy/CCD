using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

class Program
{
    static void Main(string[] args)
    {
        var n = int.Parse(Console.ReadLine());
        var value = 100000L;
        foreach (var _ in Enumerable.Range(0, n))
        {
            value = (int)Math.Ceiling(value * 1.05 / 1000) * 1000;
        }
        Console.WriteLine(value);
    }
}