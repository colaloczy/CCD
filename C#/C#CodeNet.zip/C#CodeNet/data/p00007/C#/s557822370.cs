using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            double money = 100000;

            for (int i = n - 1; i >= 0; i--)
            {
                money *= 1.05d;

                money /= 1000;
                money = Math.Ceiling(money);
                money *= 1000;
            }
            Console.WriteLine(money);
        }
    }
}