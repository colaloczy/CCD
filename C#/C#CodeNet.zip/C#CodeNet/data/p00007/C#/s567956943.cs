using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Volume0007
{
    class Program
    {
        const long _principal = 100000;
        const double _interestRate = 1.05;

        static void Main(string[] args)
        {
            int weeks = int.Parse(Console.ReadLine());
            double repayment = Money.CalcRepayment(_principal, _interestRate, weeks);
            Console.WriteLine(repayment);
        }
    }
    class Money
    {
        internal static double CalcRepayment(double Princepal, double InterestRate, int Weeks)
        {
            double Repayment = Princepal;
            for (int n = 0; n < Weeks; ++n)
            {
                Repayment = Repayment * InterestRate;
                if (0 < Repayment % 1000 && Repayment % 1000 <= 499)
                {
                    Repayment = double.Parse((Repayment / 1000).ToString("F0")) * 1000 + 1000;
                }
                else if (500 <= Repayment % 1000)
                    Repayment = double.Parse((Repayment / 1000).ToString("F0")) * 1000;
            }

            return Repayment;
        }

    }
}

