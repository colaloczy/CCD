using System;

namespace P0007_DebtHell
{
    class Program
    {
        static void Main(string[] args)
        {
            int week = int.Parse(Console.ReadLine());

            decimal debt = 100000;

            for (int i = 1; i <= week; i++)
            {

                debt *= (decimal)1.05;

                if (!int.Parse(debt.ToString("0")).ToString().EndsWith("000")) 
                {
                    debt = Math.Ceiling(debt / 1000) * 1000;
                }

            }

            Console.WriteLine(debt.ToString("0"));


        }
    }
}