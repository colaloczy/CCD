using System;

namespace Volume0_0007
{
    class Program
    {
        static void Main(string[] args)
        {
            int week = Convert.ToInt32(Console.ReadLine());
            double debt = 100000;

            for(int i = 0; i < week;i++)
            {
                debt = debt + (debt * 0.05);
                debt = (Math.Ceiling(debt / 1000)) * 1000;
            }
            Console.WriteLine(debt);
        }
    }
}