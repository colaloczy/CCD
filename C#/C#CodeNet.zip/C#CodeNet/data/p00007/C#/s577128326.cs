using System;
class aoj
    
{
    static void Main()
    {
        string a = Console.ReadLine();
        double b = double.Parse(a);
        double e = 100000;
        for(double i = 0; i < b; i++)
        {
            e = e * 1.05;
            e = e / 1000;
            e = Math.Ceiling(e);
            e = e * 1000;
        }
        Console.WriteLine(e);
    }

}