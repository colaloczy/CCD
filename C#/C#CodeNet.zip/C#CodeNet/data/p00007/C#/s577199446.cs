using System;

public class hello
{
    public static void Main()
    {
        var g = 100000;
        var a = 1.05;
        var n = int.Parse(Console.ReadLine().Trim());
        for (int i = 0; i < n; i++)
        {
            var res1 = Math.Ceiling(g*a / 1000) * 1000;
            g = (int)res1;
        }
        Console.WriteLine(g);
    }
}