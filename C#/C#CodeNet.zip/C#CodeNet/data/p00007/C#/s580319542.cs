using System;

namespace Debt_Hell
{
    class Program
    {
        static void Main(string[] args)
        {
            int k = 100000;
            int inp = int.Parse(Console.ReadLine());
            for (int i = 0; i < inp; i++)
                k += (int)Math.Ceiling((k * 0.05) / 1000) * 1000;
            Console.WriteLine(k.ToString());
        }
    }
}