using System;
using System.Collections.Generic;
using System.Linq;

class Program {

    static int Main(string[] args) {
        int n = int.Parse(Console.ReadLine());

        decimal v = 100000;

        for (int i = 0; i < n; i++) {
            decimal r = v * 5 / 100;
            decimal mod = r % 1000;

            if (mod > 0) {
                r = r + 1000 - mod;
            }

            v += r;
        }

        Console.WriteLine("{0}", v);

        return 0;
    }
}