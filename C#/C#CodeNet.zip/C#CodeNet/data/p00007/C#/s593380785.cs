using System;
using System.Collections.Generic;
using System.Text;

namespace mondai0007
{
    class Program
    {
        static double rishi = 0.05;

        static int Main(string[] args)
        {
            double gankin = 100000;
            double input = double.Parse(Console.ReadLine());
            int zougaku = 0;

            for (int i = 0; i < input; i++)
            {
                zougaku = (int)(gankin * rishi);

                if (zougaku % 1000 != 0)
                {
                    zougaku = (int)Math.Ceiling((double)zougaku / 1000) * 1000;
                }

                gankin += zougaku;
            }

            Console.WriteLine(gankin.ToString());

            return 0;

        }

    }
}