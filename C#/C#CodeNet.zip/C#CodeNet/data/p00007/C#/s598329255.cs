using System;
class test
{
	static void Main()
	{
		double debt = 100000;
		int n = int.Parse(Console.ReadLine());

		for ( int i = 0; i < n; i++ )
		{
			debt = Math.Ceiling((debt * 1.05) / 1000 ) * 1000;
		}

		Console.WriteLine(debt);
	}
}