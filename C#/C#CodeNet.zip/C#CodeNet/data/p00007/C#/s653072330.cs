using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int b = int.Parse(Console.ReadLine());
            double a = 100;
            for(int c = 0; c < b; c++)
            {
                a = a * 1.05;
                double e = a % 1;
                if (e == 0)
                    a = a - e;
                else
                    a = a - e + 1;
            }
            Console.WriteLine(a*1000);
        }
        
    }
}