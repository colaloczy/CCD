using System;

namespace AOJ
{
    class DebtHell
    {
        public static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            int m = 100000;
            for (int i = 1; i <= n; i++)
            {
                int debt = (int)Math.Ceiling(m * 0.05 / 1000) * 1000;
                m += debt;
            }
            Console.WriteLine(m);
        }
    }
}