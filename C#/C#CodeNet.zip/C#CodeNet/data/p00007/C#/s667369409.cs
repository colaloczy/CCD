using System;
namespace aizu
{
    class No0007
    {
        public static void Main()
        {
            int n;
            int money = 100000;
            string[] input = Console.ReadLine().Split();
            n = int.Parse(input[0]);
            for(int i=1;i <= n;++i){
                money = (int)(money * 1.05);
                if(money % 1000 != 0){
                    money = (money / 1000 + 1) * 1000;
                }
            }
            Console.WriteLine(money.ToString());
        }
    }
}