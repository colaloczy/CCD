using System;

public class my
{
	public static void Main()
	{
		var n = my.GetInt();
		var dept = 100000.0;
		
		for(int i = 0; i < n; i++) {
			dept *= 1.05;
			dept /= 1000.0;
			dept = Math.Ceiling(dept);
			dept *= 1000.0;
		}
		
		Console.WriteLine((long)dept);
	}
	
	private static int GetInt()
	{
		return int.Parse(Console.ReadLine());
	}
}