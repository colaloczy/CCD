using System;

public class Program {
  public static void Main() {
    const int INIT_DEBT = 100000;
    const double INTEREST_PERCENT = 1.05;
    int debt = INIT_DEBT;
    int weeks = int.Parse(Console.ReadLine());
    for (int i = 0; i < weeks; i++) {
      debt = Ceiling(debt * INTEREST_PERCENT);
    }
    Console.WriteLine(debt);
  }

  private static int Ceiling(double value) {
    return (int)(Math.Ceiling(value / 1000) * 1000);
  }
}