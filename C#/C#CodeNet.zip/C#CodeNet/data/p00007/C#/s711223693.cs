using System;


namespace _007_DebtHell
{
	class Program
	{
		static void Main ( string[] args )
		{
			int weekCount = int.Parse (Console.ReadLine ());

			double debt = 100000;

			for (int lp = 0; lp < weekCount; lp++)
			{
				double adddebt = Math.Ceiling (debt * 0.05 / 1000) * 1000;
				debt += adddebt;
			}

			Console.WriteLine (debt);
		}
	}
}