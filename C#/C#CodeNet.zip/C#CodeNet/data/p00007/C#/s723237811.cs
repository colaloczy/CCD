using System;


namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            const double PRINCI = 100000;
            while (true)
            {
                var numstr = Console.ReadLine();
                int num = 0;
                try
                {
                    num = int.Parse(numstr);
                }
                catch (Exception)
                {
                    return;
                }

                var sum = PRINCI;
                for (int i = 0; i < num; i++)
                {
                    sum *= 1.05;
                    sum /= 1000;
                    sum = Math.Ceiling(sum);
                    sum *= 1000;
                }

                Console.WriteLine(sum);
            }

        }
    }
}