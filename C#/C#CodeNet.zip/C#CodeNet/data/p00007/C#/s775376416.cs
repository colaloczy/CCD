using System;

namespace _0007
{
    class Program
    {
        static void Main(string[] args)
        {
            double debt = 100000;
            var appointedWeek = int.Parse(Console.ReadLine());

            for (int weekCount = 0; weekCount< appointedWeek; weekCount++)
            {
                debt = debt * (1.00 + 0.05);
            }
            var rest = debt % 10000;
            debt = debt - rest + 10000.0;

            Console.Write("{0}\n",(int)(debt));
        }
    }
}