using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.IO;

public class Sample8{

	public static void Main(){

		int week = int.Parse(Console.ReadLine ());

		double result = debutResult (week);

		Console.WriteLine (result);

	}

	public static double debutResult (int week){

		double debut = 100000;

		double result = 0;

		for (int i = 0; i < week; i++){

			result = debut + (debut * 0.05);
			debut += debut * 0.05;
		}

		result *= 0.0001;

		result = Math.Ceiling (result);

		result *= 1000;

		return result;
	}
}