using System;
//using System.Text;
//using System.Linq;
class Program
{
    static void Main()
    {
        double a = 100;
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++) a=Math.Ceiling(a *= 1.05);
        Console.WriteLine((int)a * 1000);
    }
}