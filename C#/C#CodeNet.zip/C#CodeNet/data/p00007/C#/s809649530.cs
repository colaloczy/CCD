using System;
class main
{
    static void Main(String[] args)
    {
        int n = int.Parse(Console.ReadLine());
        int b = 100000;
        for (int i = 0; i < n; i++)
        {
            b = (((int)((double)b * 1.05)+999)/1000)*1000;
        }
        Console.WriteLine(b);
    }
}