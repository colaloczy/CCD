using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AOJ
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine(getDobt(n, 100000));
        }

        static int getDobt(int c, int value)
        {
            if (c-- == 0) return value;
            value += (value*5/100);
            if (value % 1000 != 0) { value /= 1000; value += 1; value *= 1000; }
            return getDobt(c, value);
        }
    }
}