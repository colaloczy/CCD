using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.IO;

public class Sample8{

	public static void Main(){

		int week = int.Parse(Console.ReadLine ());

		double result = debutResult (week);

		Console.WriteLine (result);

	}

	public static double debutResult (int week){

		double debut = 100000;

		for (int i = 0; i < week; i++){
		
			debut = debut * 1.05;
		}

		debut *= 0.001;
//
		debut = Math.Ceiling (debut);
//
		debut *= 1000;

		return debut;
	}
}