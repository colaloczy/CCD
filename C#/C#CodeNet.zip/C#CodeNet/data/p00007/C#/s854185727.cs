using System;
using System.Linq;

class AOJ0007
{
    static void Main()
    {
        var debt = 100000d;
        for(var _ = int.Parse(Console.ReadLine()); _ > 0 ; _--)
        {
            debt = Math.Ceiling(debt * 1.05 / 1000) * 1000;
        }
        Console.WriteLine(debt);
    }
}