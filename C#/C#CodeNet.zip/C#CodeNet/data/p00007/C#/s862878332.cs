using System;

public class DebtHell
{
	public static void Main(string[] args)
	{
		int week = int.Parse(Console.ReadLine());
		uint cache = 100000;
		for (int i = 0; i < week; i++)
		{
			cache = (uint)Math.Ceiling(cache * 1.05 / 1000) * 1000;
		}
		Console.WriteLine(cache);
	}
}