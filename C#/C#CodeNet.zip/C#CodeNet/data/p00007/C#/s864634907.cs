using System;

public class Program
{
    private static void Main()
    {
        var n = int.Parse(Console.ReadLine());

        var initialDebt = 100000;
        for (var i = 0; i < n; ++i)
        {
            initialDebt += initialDebt * 5 / 100;
            if (initialDebt % 1000 > 0)
            {
                initialDebt += 1000 - initialDebt % 1000;
            }
        }

        Console.WriteLine(initialDebt);
    }
}