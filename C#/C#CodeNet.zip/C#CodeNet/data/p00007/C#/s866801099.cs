using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prob0007
{
    class Program
    {
        const int defMoney = 100000;

        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int money = defMoney;
            for (int i = 0; i < n; i++)
            {
                money += (int)(money * 0.05);
            }
            if (money % 10000 != 0)
                Console.WriteLine((money / 10000 + 1) * 10000);
            else
                Console.WriteLine(money);
        }


    }
}