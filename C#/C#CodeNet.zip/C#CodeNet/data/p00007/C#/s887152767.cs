using System;
using System.Collections.Generic;
using System.Linq;

namespace AOJ
{
  class Program
  {
    public static void Main(string[] args)
    {
      var n = int.Parse(Console.ReadLine());
      var debt = 100000;
      foreach (var i in Enumerable.Range(0, n))
      {
        var tmp = (double)debt * 1.05;
        if (tmp % 1000 != 0)
          debt = (int)((tmp / 1000) + 1) * 1000;
        else
          debt = (int)tmp;
      }
      Console.WriteLine(debt);
    }
  }
}