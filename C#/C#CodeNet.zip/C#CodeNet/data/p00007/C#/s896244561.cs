using System;


namespace _007_DebtHell
{
	class Program
	{
		static void Main ( string[] args )
		{
			int weekCount = int.Parse (Console.ReadLine ());

			int debt = 100000;

			for (int lp = 0; lp < weekCount; lp++)
			{
				int adddebt = (int) (debt * 0.05);
				int rest = adddebt % 1000;

				if (rest != 0)
					adddebt = adddebt - rest + 1000;

				debt += adddebt;
			}

			Console.WriteLine (debt);
		}
	}
}