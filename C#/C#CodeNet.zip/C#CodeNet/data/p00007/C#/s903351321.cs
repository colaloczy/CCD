using System;

class Program
{
	static void Main()
	{
		int n = int.Parse(Console.ReadLine());
		
		double m = 100000;
		double r = 0.05D;
		double w;
		
		for (int i = 0; i < n; i++)
		{
			w = Math.Ceiling((m * r) / 1000) * 1000;
			m += w;
		}
		
		Console.WriteLine(m.ToString());
	}
}

