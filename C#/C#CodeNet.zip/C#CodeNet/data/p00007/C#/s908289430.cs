using System;

class Problem0007
{
    static void Main(string[] args)
    {
        string line = Console.ReadLine();
        int week = int.Parse(line);
        Console.WriteLine(GetDebt(week));
    }

    static int GetDebt(int week)
    {
        if (week == 0)
        {
            return 100000;
        }
        else
        {
            return (int)Math.Ceiling(GetDebt(week - 1) * 1.05 / 1000.0) * 1000;
        }
    }
}