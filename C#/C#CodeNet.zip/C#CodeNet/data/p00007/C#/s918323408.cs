using System;
using System.Collections.Generic;
using System.Text;

namespace mondai0007
{
    class Program
    {
        static double rishi = 0.05;

        static int Main(string[] args)
        {
            double gankin = 100000;
            double input = double.Parse(Console.ReadLine());

            for (int i = 0; i < input; i++)
            {
                gankin = gankin + (gankin * rishi);
            }

            Console.Write((Math.Ceiling(gankin / 10000) * 10000).ToString());

            return 0;
        }

    }
}