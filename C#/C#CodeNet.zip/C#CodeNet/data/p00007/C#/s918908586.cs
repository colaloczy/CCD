using System;

namespace AOJ.Volume0
{
    class Program0007
    {
        static void Main(string[] args)
        {
            int money = 100000;
            int weeks;

            weeks = int.Parse(Console.ReadLine());

            for (int i = 0; i < weeks; i++)
            {
                money = (int)Math.Ceiling(money * 1.05 / 1000) * 1000;
            }

            Console.WriteLine(money);
        }
    }
}