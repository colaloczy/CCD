using System;

namespace v0_0007
{
    class Program
    {
        static void Main(string[] args)
        {
            var week = int.Parse(Console.ReadLine());
            int debt = 100;
            for (int i = 0; i < week; i++)
            {
                debt = ((debt * 105) / 100) + ((debt % 20) > 0 ? 1 : 0);
            }
            Console.WriteLine("{0:f0}000", debt);
        }
    }
}