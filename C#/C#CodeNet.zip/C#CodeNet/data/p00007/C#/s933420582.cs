using System;
namespace ConsoleApplication1{
    class Program{
        static void Main(string[] args){
            int n = Console.Read();
            int debt = 100000;
            for (int i = 0; i < n; i++) {
                debt += (int)(debt * 0.05);
                if (debt % 1000 != 0) {
                    debt /= 1000;
                    debt *= 1000;
                    debt += 1000;
                }
            }
            Console.WriteLine(debt);
        }
    }
}