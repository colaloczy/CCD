using System;

public class p0007
{
	p0007(){
		string str;
		int n, s, t;
		
		while((str=Console.ReadLine()) != null){
			n = int.Parse(str);
			s = 100000;
			while(0 < n--){
				s += (int)((double)s*0.05);
				t = s % 1000;
				if(t != 0) s += (1000-t);
			}
			Console.WriteLine("{0}", s);
		}
	}
	
	public static int Main(string[] args){
		new p0007();
		return 0;
	}
}