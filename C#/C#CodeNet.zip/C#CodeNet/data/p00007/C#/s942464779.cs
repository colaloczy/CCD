using System;

class Volumen0
{
    static void Main()
    {
        int ans = 100000;
        double sem = double.Parse(Console.ReadLine());
        for (int i = 0; i < sem; ++i)
        {
            double tmp = ans * 0.05;
            int tmp2 = (int)tmp / 1000;
            if (tmp2 != tmp / 1000)
            {
                ans += (tmp2 + 1) * 1000;
            }
            else
            {
                ans += tmp2 * 1000;
            }
        }
        Console.Out.WriteLine(ans);
    }
}
