using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int s = 100;
            for (int i = 0; i < n; i++)
                s = (int)Math.Ceiling(s * 1.05);
            Console.WriteLine("{0}000", s);
        }
    }
}