using System;

namespace _0007
{
    class Program
    {
        static void Main(string[] args)
        {
            int week;
            week = int.Parse(Console.ReadLine());

            int debt = 100000;
            while(week > 0){

                double tmp = Math.Ceiling(((double)debt * 1.05) / 1000.0);
                debt = (int)(tmp * 1000);

                week--;
            }
            Console.WriteLine(debt);

        }
    }
}

