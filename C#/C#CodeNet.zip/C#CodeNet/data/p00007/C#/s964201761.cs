using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prob0007
{
    class Program
    {
        const int defMoney = 100000;

        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int money = defMoney;
            for (int i = 0; i < n; i++)
            {
                money += (int)(money * 0.05);
                if (money % 1000 != 0)
                    money = (money / 1000 + 1) * 1000;
            }
            Console.WriteLine(money);
            
        }


    }
}