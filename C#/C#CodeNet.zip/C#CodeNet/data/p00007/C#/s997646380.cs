using System;

class Program
{
    static void Main()
    {

        int n = int.Parse(Console.ReadLine());

        double price = 100000;
        for (int i = 0; i < n; i++)
        {
            price = price * 1.05;

            price = price / 1000;
            double tmp = Math.Ceiling(price);
            price = tmp * 1000;

        }

        Console.WriteLine(price);
    }
}
