using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AOJ
{
	class Program
	{
		static void Main(string[] args)
		{
			var n = int.Parse(Console.ReadLine());
			double r = 100000;
			for (int i = 0; i < n; i++)
			{
				r *= 1.05;
				if (r % 1000 != 0) r += 1000 - r % 1000;
			}
			Console.WriteLine(r);
		}
	}
}