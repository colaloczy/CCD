using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Programminng
{
    class AOJ_Volume0013
    {
        public static void Main(string[] args)
        {
            int[] stack = new int[10]{0,0,0,0,0,0,0,0,0,0};
            int i = 0;

            while (true)
            {
                string input = Console.ReadLine();
                if (string.IsNullOrEmpty(input)) break;

                int line = int.Parse(input);

                if (line == 0)
                {
                    i--;
                    Console.WriteLine(stack[i]);
                }
                else
                {
                    stack[i] = line;
                    i++;
                }
            }
        }
    }
}