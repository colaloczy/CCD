using System;
using System.Collections.Generic;

namespace P0013_SwitchingRailroadCars
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> lines = new List<string>();
            string readLine;

            do
            {
                readLine = Console.ReadLine();
                if (readLine != null)
                {
                    lines.Add(readLine);
                }
            }
            while (readLine != null);

            List<string> rail = new List<string>();

            foreach (string line in lines)
            {

                if (line == "0")
                {
                    Console.WriteLine(rail[0]);
                    rail.RemoveAt(0);
                }
                else 
                {
                    rail.Insert(0, line);
                }

            }

        }

    }
}