using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace mondai0013
{
	class Program
	{
		static void Main(string[] args)
		{
			int[]	car	= new int[ 10 ];
			int		idx	= 0;
			
			while( true ) {
				var	s	= Console.ReadLine();
				if( s == null ) {
					break;
				}
				var	n	= int.Parse( s );
				if( n == 0 ) {
					idx--;
					Console.WriteLine( car[ idx ] );
				} else {
					car[ idx ]	= n;
					idx++;
				}
			}
		}
	}
}