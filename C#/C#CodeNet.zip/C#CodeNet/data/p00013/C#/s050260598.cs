using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0013
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> numberList = new List<string>();
            List<string> departureList = new List<string>();
            string str = "";
            while ((str = Console.ReadLine()) != null)
            {
                if (str == "0")
                {
                    departureList.Add(numberList[numberList.Count - 1]);
                    numberList.RemoveAt(numberList.Count - 1);
                }
                else
                {
                    numberList.Add(str);
                }
            }
            foreach (var item in departureList)
            {
                Console.WriteLine(item);
            }
        }
    }
}

