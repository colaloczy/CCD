using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Volume0013
{
    class Program
    {
        static List<int> _garage = new List<int>();
        static void Main(string[] args)
        {
            string trainNum = "";
            while ((trainNum = Console.ReadLine()) != null)
            {
                if (trainNum == "0")
                {
                    Console.WriteLine(_garage[_garage.Count - 1]);
                    _garage.Remove(_garage[_garage.Count - 1]);
                }
                else
                {
                    _garage.Add(int.Parse(trainNum));
                }
            }
        }
    }
}

