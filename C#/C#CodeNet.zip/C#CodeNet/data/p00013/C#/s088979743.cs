using System;
using System.Collections.Generic;

public class p0013
{
	p0013(){
		string str;
		Stack<string> stk = new Stack<string>();
		
		while((str=Console.ReadLine()) != null){
			if(str != "0") stk.Push(str);
			else if(stk.Count > 0) Console.WriteLine(stk.Pop());
		}
	}
	
	public static int Main(string[] args){
		new p0013();
		return 0;
	}
}