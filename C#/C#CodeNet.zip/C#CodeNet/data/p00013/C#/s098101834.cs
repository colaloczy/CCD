using System;
using System.Collections.Generic;

class MyClass
{
    static void Main(string[] args)
    {
        Stack<string> train = new Stack<string>();
        string str;
        while ((str = Console.ReadLine()) != null)
        {
            if (str == "0")
            {
                Console.WriteLine(train.Pop());
            }
            else
            {
                train.Push(str);
            }
        }
    }
}
