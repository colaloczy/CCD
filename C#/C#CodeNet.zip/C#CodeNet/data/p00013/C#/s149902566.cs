using System;
using System.Collections.Generic;
					
public class Program
{
	public static void Main()
	{
		var stk = new Stack<int>();
		
		string s;

		while( null != ( s = Console.ReadLine()) ) {
			var n = int.Parse(s);
			
			if(n==0) Console.WriteLine(stk.Pop());
			else	stk.Push(n);
		}
	}
}