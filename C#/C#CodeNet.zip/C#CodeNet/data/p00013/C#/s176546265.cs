using System;
using System.Collections.Generic;
using System.Text;

class Program
{
    static void Main()
    {
        StringBuilder sb = new StringBuilder();
        Stack<string> stk = new Stack<string>();
        string s = "";
        while ((s = Console.ReadLine()) != null)
        {
            if (s == "0")
            {
                sb.AppendLine(stk.Pop());
            }
            else
            {
                stk.Push(s);
            }
        }
        Console.Write(sb);
    }
}
