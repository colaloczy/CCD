using System;
using System.Collections.Generic;

namespace AOJ.Volume0
{
    class Program0013
    {
        static void Main(string[] args)
        {
            string line;
            Queue<string> operatingQueue = new Queue<string>();
            Stack<string> trainStack = new Stack<string>();

            while((line = Console.ReadLine()) != null)
            {
                operatingQueue.Enqueue(line);
            }

            foreach (var op in operatingQueue)
            {
                if (op == "0")
                {
                    Console.WriteLine(trainStack.Pop());
                }
                else
                {
                    trainStack.Push(op);
                }
            }
        }
    }
}