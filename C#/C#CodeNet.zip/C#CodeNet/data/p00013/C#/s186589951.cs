using System;
using System.Collections.Generic;
using System.Linq;

namespace AOJ
{
  class Program
  {
    static void Main()
    {
      var stack = new Stack<int>();
      foreach (var i in ReadNumbers())
      {
        if (i == 0)
          Console.WriteLine(stack.Pop());
        else
          stack.Push(i);
      }
    }

    static IEnumerable<int> ReadNumbers()
    {
      string line;
      while (!string.IsNullOrEmpty(line = Console.ReadLine()))
        yield return int.Parse(line);
    }
  }
}