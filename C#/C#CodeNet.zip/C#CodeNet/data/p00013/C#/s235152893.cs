using System;


class AOJ
{
    public static void Main()
    {
        int[] a = new int[10];
        int c=0;

        while (true)
        {
            string s = Console.ReadLine();
            if (s == null) break;

            int n = int.Parse(s);

            if (n == 0)
            {
                c--;
                Console.WriteLine(a[c]);
            }
            else
            {
                a[c] = n;
                c++;
            }
        }
    }
}