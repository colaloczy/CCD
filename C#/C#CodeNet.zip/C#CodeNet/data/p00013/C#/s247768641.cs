using System;
using System.Collections.Generic;

namespace _0013
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack<int> train = new Stack<int>();
            while (true)
            {
                string s = Console.ReadLine();
                if (s == "")
                {
                    break;
                }
                int n = int.Parse(s);
                if (n == 0)
                {
                    Console.WriteLine(train.Pop());
                }
                else
                {
                    train.Push(n);
                }
            }
        }
    }
}