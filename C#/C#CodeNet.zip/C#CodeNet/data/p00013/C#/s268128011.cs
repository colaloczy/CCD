using System;
class aoj
{static void Main()
    {
        int[] a = new int[10];
        int[] z = new int[50];
        int i = 0, j = 0, k = 0; ;
        for (;;)
        {
            int b = int.Parse(Console.ReadLine());
            if (b == 0)
            {
                z[j] = a[i-1];
                Array.Clear(a, i-1, 1);
                j++;
                i--;
                k = 1;
            }
            else
            {
                a[i] = b;
                i++;
                k = 1;
            }
            if (k == 1 && a[0] == 0)
            {
                break;
            }
        }
        for(int x = 0; x < j; x++)
        {
            Console.WriteLine(z[x]);
        }
    }
}