using System;
using System.Collections;
class Program{
	static void Main(){
		string s;
		var st = new Stack();
		while((s = Console.ReadLine()) != null){
			if(s == "0") Console.WriteLine(st.Pop());
  			else st.Push(s);
		}
	}
}