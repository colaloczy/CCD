using System;
using System.Collections.Generic;

namespace Volume0_0013
{
	class Program
	{
		static void Main(string[] args)
		{
			Stack<int> vs = new Stack<int>();

			for(int i = 0; i < 100; i++) {
				string str = Console.ReadLine();
				if(str == null) {
					break;
				}

				int v = int.Parse(str);

				if(v == 0) {
					Console.WriteLine(vs.Pop());
				}
				else {
					vs.Push(v);
				}
			}
		}
	}
}

