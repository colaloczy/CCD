using System;
using System.Collections.Generic;
using System.Linq;

class Program {

    static int Main(string[] args) {
        Stack<int> s = new Stack<int>();
        for (int i = 0; i < 100; i++) {
            string v = Console.ReadLine();
            if (v.Length == 0) { break; }

            int n = int.Parse(v);
            if (n == 0) {
                Console.WriteLine(s.Pop());
                continue;
            }
            s.Push(n);
        }

        return 0;
    }
}

