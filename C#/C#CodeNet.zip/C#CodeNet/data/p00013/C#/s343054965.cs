using System;
using System.Collections.Generic;
using System.Linq;

class Program {

    static int Main(string[] args) {
        List<int> list = new List<int>();

        while (true) {
            string v = Console.ReadLine();
            if (v.Length == 0) { break; }

            //string[] vs = v.Split(' ');
            list.Add(int.Parse(v));
        }

        Stack<int> s = new Stack<int>();
        for (int i = 0; i < list.Count; i++) {
            if (list[i] == 0) {
                Console.WriteLine(s.Pop());
                continue;
            }
            s.Push(list[i]);
        }

        return 0;
    }
}

