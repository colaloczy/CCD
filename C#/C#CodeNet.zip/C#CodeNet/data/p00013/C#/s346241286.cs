using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0013
{
    class Program
    {
        static void Main(string[] args)
        {
            string number = "";
            List<string> train = new List<string>();
            while ((number = Console.ReadLine()) != null)
            {
                if (number == "0")
                {
                    Console.WriteLine(train[train.Count - 1]);
                    train.RemoveAt(train.Count - 1);
                }
                else
                {
                    train.Add(number);
                }
            }
        }
    }
}

