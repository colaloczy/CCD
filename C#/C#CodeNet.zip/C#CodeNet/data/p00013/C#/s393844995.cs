using System;
using System.Collections.Generic;

namespace AOJ.Volume0
{
    class Program0013
    {
        static void Main(string[] args)
        {
            string line;
            Queue<int> operatingQueue = new Queue<int>();
            Stack<int> trainStack = new Stack<int>();

            while((line = Console.ReadLine()) != null)
            {
                operatingQueue.Enqueue(int.Parse(line));
            }

            foreach (var op in operatingQueue)
            {
                if (op == 0)
                {
                    Console.WriteLine(trainStack.Pop());
                }
                else
                {
                    trainStack.Push(op);
                }
            }
        }
    }
}