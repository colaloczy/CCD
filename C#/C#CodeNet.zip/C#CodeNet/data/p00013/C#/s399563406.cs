using System;

namespace _0013
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                string ghhj = Console.ReadLine();
                int a = int.Parse(ghhj);
                int[] sharyo = new int[10];
                int kazoeteru=1;
                if (a > 0) { sharyo[a] = kazoeteru ;kazoeteru++; }
                else
                {
                    for (int i = 0; i < 10; i++)
                    {
                        if (sharyo[i] == kazoeteru - 1)
                        {
                            Console.WriteLine(sharyo[i]);
                        }
                    }
                }   
            }
        }
    }
}