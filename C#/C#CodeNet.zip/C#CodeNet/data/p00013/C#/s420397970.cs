using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace ConsoleApplication26
{
    class Program
    {
        static void Main(string[] args)
        {
			List<int> a = new List<int>();
			string line;
			while((line=Console.ReadLine())!=null)
			{
				int b = int.Parse(line);
				if(b==0)
				{
				Console.WriteLine(a[a.Count-1]);
				a.RemoveAt(a.Count-1);
				}
				if(b!=0) a.Add(b);
				}
		}
    }
}
 
 