using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace mondai0013
{
	class Program
	{
		static void Main(string[] args)
		{
			var	stack	= new Stack<string>();

			while( true ) {
				var	s	= Console.ReadLine();
				if( s == null ) {
					break;
				}
				if( s == "0" ) {
					Console.WriteLine( stack.Pop() );
				} else {
					stack.Push( s );
				}
			}
		}
	}
}