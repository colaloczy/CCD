using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AOJ
{
	class Program
	{
		static void Main(string[] args)
		{
			var str = "";
			var stack = new Stack<int>();
			while ((str = Console.ReadLine()) != null)
			{
				var n = int.Parse(str);
				if (n != 0) stack.Push(n);
				else Console.WriteLine(stack.Pop());
			}
		}
	}
}