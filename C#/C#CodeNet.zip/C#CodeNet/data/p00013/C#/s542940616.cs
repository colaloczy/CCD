using System;
using System.Collections.Generic;

namespace HelloWorld
{
    class Program
    {
        static void Main()
        {
            const int MAX = 50;
            string line;
            Stack<string> car = new Stack<string>(MAX);
            while ((line = Console.ReadLine()) != null)
            {
                if (line != "0")
                {
                    car.Push(line);
                }
                else
                {
                    string dep = car.Pop();
                    Console.Out.WriteLine(dep);
                }
            }
        }
    }
}
