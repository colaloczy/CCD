using System;
using System.Collections.Generic;
using System.Linq;

class Program {

    static int Main(string[] args) {
        int cntX = 0;
        List<int> list = new List<int>();
        while (true) {
            string v = Console.ReadLine();

            int n = int.Parse(v);
            if (n == 0) { cntX--; }
            else { cntX++; }

            list.Add(n);
            if (cntX == 0) { break; }
        }

        Stack<int> s = new Stack<int>();
        for (int i = 0; i < list.Count; i++) {
            if (list[i] == 0) {
                Console.WriteLine(s.Pop());
                continue;
            }
            s.Push(list[i]);
        }

        return 0;
    }
}

