using System;
using System.Collections;

class main
{
    static void Main(string[] args)
    {
        ArrayList list = new ArrayList();
        ArrayList lista = new ArrayList();
        string s;
        while ((s = Console.ReadLine()) != null)
            if (s == "0")
            {
                lista.Add(list[list.Count - 1]);
                list.RemoveAt(list.Count - 1);
            }
            else
            {
                list.Add(s);
            }
        for (int i = 0; i < lista.Count; ++i)
            Console.WriteLine(lista[i]);
    }
}