using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication58
{
    class Program
    {
        static void Main()
        {
            List<int> s = new List<int>();
            while (true)
            {
                string a = Console.ReadLine();
                if (a == null) break;
                int b = int.Parse(a);
                if (b != 0) s.Add(b);
                else
                {
                    Console.WriteLine(s[s.Count-1]);
                    for(int d = s.Count-1; d > 0; d--)
                    {
                        s[d] = s[d-1];
                    }
                }
            }
        }
    }
}