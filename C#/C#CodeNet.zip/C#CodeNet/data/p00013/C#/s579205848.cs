using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AthleteProgramming2
{
    
    class Program
    {
        static void Main()
        {
            string str;
            Stack<int> stack = new Stack<int>();
            while ((str = Console.ReadLine()) != null)
            {
                int num = int.Parse(str);
                if (num != 0)
                {
                    stack.Push(num);
                }else
                {
                    Console.WriteLine(stack.Pop());
                }
            }
        }
    }
}