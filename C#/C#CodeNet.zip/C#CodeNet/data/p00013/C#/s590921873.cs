using System;
class aoj
{static void Main()
    {
        int[] a = new int[10];
        int i = 0, j = 0, k = 0; ;
        for (;;)
        {
            int b = int.Parse(Console.ReadLine());
            if (b == 0)
            {
                
                j++;
                i--;
                Console.WriteLine(a[i]);
                Array.Clear(a, i, 1);
            }
            else
            {
                a[i] = b;
                i++;
                k = 1;
            }
            if (k == 1 && a[0] == 0)
            {
                break;
            }
        }
    }
}