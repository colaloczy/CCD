using System;
using System.Collections.Generic;

namespace Aizu
{
    class OnlineJudge
    {
        public static void Main()
        {
            var stack = new Stack<string>(10);
            do {
                var num = Console.ReadLine();
                if(num == "0") {
                    Console.WriteLine(stack.Pop());
                } else {
                    stack.Push(num);
                }
            } while(stack.Count != 0);
        }
    }
}