using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
 
namespace ConsoleApplication26
{
    class Program
    {
        static void Main(string[] args)
        {
			List<int> a = new List<int>();
			while(true)
			{
				int b = int.Parse(Console.ReadLine());
				if(b==0)
				{
				Console.WriteLine(a[a.Count-1]);
				a.RemoveAt(a.Count-1);
				}
				if(b!=0) a.Add(b);
				}
		}
    }
}
 
 