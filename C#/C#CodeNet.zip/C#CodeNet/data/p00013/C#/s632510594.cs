using System;
using System.Collections.Generic;
using System.Text;

namespace SwitchingRailRoad
{
    class Program
    {
        static void Main(string[] args)
        {
            var sb = new StringBuilder();
            var stk = new Stack<int>();

            while (true)
            {
                var str = Console.ReadLine();
                try
                {
                    var input = int.Parse(str);
                    if (input == 0)
                    {
                        int temp = stk.Pop();
                        sb.AppendLine(temp.ToString());
                    }
                    else
                    {
                        stk.Push(input);
                    }
                }
                catch
                {
                    Console.Write(sb);
                    break;
                }
             }

        }
    }
}

