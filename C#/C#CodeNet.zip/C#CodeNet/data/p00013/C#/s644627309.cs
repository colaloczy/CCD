using System;
using System.Collections.Generic;
using System.Linq;

class AIDU0013
    {
        public static void Main(){
            Stack<uint> Copula= new Stack<uint>();
            Queue<uint> Gone = new Queue<uint>();
            string s;
            uint n;
            while(true) {
                s=Console.ReadLine();
                if(string.IsNullOrEmpty(s))break;
                n=uint.Parse(s);
                if(n!=0) { Copula.Push(uint.Parse(s));
                } else Gone.Enqueue(Copula.Pop());
            }
            while(Gone.Count>0) {
                Console.WriteLine(Gone.Dequeue());
            }
        }
    }