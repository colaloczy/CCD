using System;
using System.Collections.Generic;

namespace Volume0_0013
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack<int> trains = new Stack<int>();
            string input;
            while ((input = Console.ReadLine()) != null)
            {
                if (input == "0") Console.WriteLine( trains.Pop() );
                else trains.Push(Convert.ToInt32(input)); 
            }
        }
    }
}