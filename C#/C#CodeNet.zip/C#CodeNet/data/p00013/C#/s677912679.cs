using System.Collections.Generic;
using System;

public class hello
{
    public static void Main()
    {
        var rail= new Stack<int>();
        string line;
        for (; (line = Console.ReadLine()) != null;)
        {
            var n = int.Parse(line);
            if (n == 0)
            {
                var train = rail.Pop();
                Console.WriteLine(train);
            }
            else rail.Push(n);
        }
    }
}