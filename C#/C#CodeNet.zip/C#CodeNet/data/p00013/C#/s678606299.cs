using System;
using System.Collections.Generic;
class _0013
{
    public static void Main()
    {
        string str;
        byte n;
        byte[] stackTrains = new byte[10];
        for (byte i = 0; i < 10; i++) stackTrains[i] = 0;
        List<byte> ejectTrains = new List<byte>();
        byte nowStacks = 0;
        while ((str = Console.ReadLine()) != null)
        {
            n = byte.Parse(str);
            if (n != 0)
            {
                stackTrains[nowStacks] = n;
                nowStacks++;
            }
            else
            {
                nowStacks--;
                ejectTrains.Add(stackTrains[nowStacks]);
            }
        }
        for (int i = 0; i < ejectTrains.Count; i++) Console.WriteLine(ejectTrains[i]);
    }
}