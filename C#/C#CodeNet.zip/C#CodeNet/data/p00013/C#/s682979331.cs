using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0013
{
    class Program
    {
        static void Main(string[] args)
        {

            string str = "";
            List<int> train = new List<int>();

            while ((str = Console.ReadLine()) != null)
            {
                int frequent = int.Parse(str);
                if (frequent != 0)
                {
                    train.Add(frequent);
                }
                else
                {
                    Console.WriteLine(train[train.Count() - 1]);
                    train.RemoveAt(train.Count() - 1);
                }
            }
        }
    }
}

