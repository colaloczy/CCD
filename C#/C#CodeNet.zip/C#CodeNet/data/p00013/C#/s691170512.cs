using System;

class AOJ{
  static void Main(string[] args)
  {
    int[] stack = new int[101];
    int i = 0;
    string s;

    while ((s = Console.ReadLine()) != null){

      int n = int.Parse(s);

      if (n == 0){
        i--;
        Console.WriteLine(stack[i]);
      }

      else{
        stack[i] = n;
        i++;
      }
    }
  }
}