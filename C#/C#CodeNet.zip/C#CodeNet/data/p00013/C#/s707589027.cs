using System;
using System.Collections.Generic;

namespace AOJ0013
{
    class Program
    {
        static void Main()
        {
            var stack = new Stack<int>();
            foreach (var op in ReadOperation())
            {
                if (op == 0)
                {
                    Console.WriteLine(stack.Pop());
                }
                else
                {
                    stack.Push(op);
                }
            }
        }

        public static IEnumerable<int> ReadOperation()
        {
            string line;
            while ((line = Console.ReadLine()) != null)
            {
                yield return int.Parse(line);
            }
        }
    }
}