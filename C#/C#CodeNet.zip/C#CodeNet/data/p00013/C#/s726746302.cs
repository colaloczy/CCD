using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OJcsharp
{
    class Program
    {
        static void Main(string[] args)
        {
            int []output=new int[10000];
            int output_count=0;
            int input_count=0;
            int []input_casher=new int[10];
            string str = Console.ReadLine();
            do
            {
                if (str == "0")
                {
                    output[output_count] = input_casher[input_count - 1];
                    input_count--;
                    output_count++;
                }
                else
                {
                    input_casher[input_count] = int.Parse(str);
                    input_count++;
                }
                str = Console.ReadLine();
            } while (String.IsNullOrEmpty(str) == false);
            for (int n = 0; n < output_count; n++)
                Console.WriteLine(output[n]);
        }
    }
}