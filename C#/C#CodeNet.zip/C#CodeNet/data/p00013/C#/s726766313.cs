using System;
using System.Collections.Generic;
using System.Linq;

public class Hello
{
    public static void Main()
    {
        List<int> stoppedTrain = new List<int>();
        List<int> exitTrain = new List<int>();

        string str;
        while (!((str = Console.ReadLine()) == null))
        {
            int number = int.Parse(str);
            int trainNumber = stoppedTrain.Count();
            if (number == 0)
            {
                for (int i = trainNumber - 1; i >= trainNumber - 1; i--)
                {
                    if (i == trainNumber - 1)
                    {
                        exitTrain.Add(stoppedTrain[trainNumber-1]);
                        stoppedTrain.RemoveAt(i);
                    }
                }
            }
            else
            {
                stoppedTrain.Add(number);
            }
        }

        foreach(double item in exitTrain)
        {
            Console.WriteLine(item);
        }
    }

}

