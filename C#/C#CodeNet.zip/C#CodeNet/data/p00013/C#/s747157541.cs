using System;
using System.Collections.Generic;

namespace AOJ.Volume0
{
    class SwitchingRailroadCars
    {
        public static void Main()
        {
            Stack<int> train = new Stack<int>();

            while (true)
            {
                int input = int.Parse(Console.ReadLine());
                if (input == 0)
                {
                    // 電車が出て行く
                    Console.WriteLine(train.Pop());
                    // Stackの中が空になったら終了
                    if (train.Count == 0) { break; }
                }
                else { train.Push(input); }
            }
        }
    }
}