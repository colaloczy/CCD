using System;
using System.Collections.Generic;

namespace _013_SwitchingRailroadCars
{
	class Program
	{
		static void Main ( string[] args )
		{
			string inputStr;
			Stack<string> stack = new Stack<string> (50);

			while ((inputStr = Console.ReadLine ()) != null)
			{
				if (inputStr != "0")
				{
					stack.Push (inputStr);
				}
				else
				{
					string output = stack.Pop ();
					Console.WriteLine (output);
				}
			}

		}
	}
}