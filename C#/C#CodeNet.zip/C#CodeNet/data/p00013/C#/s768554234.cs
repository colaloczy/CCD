using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder sb = new StringBuilder();
            Stack<int> stk = new Stack<int>();

            string input;

            while (!string.IsNullOrEmpty(input = Console.ReadLine()))
            {
                int n = int.Parse(input);

                if (n != 0) stk.Push(n);
                else sb.AppendLine(stk.Pop().ToString());
            }
            Console.Write(sb);
        }
    }
}