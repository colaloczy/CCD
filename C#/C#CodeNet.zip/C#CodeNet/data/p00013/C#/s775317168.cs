using System;
class aoj
{static void Main()
    {
        int[] a = new int[10];
        int i = 0, j = 0; 
        for (;;)
        {
            string y = Console.ReadLine();
            if (String.IsNullOrEmpty(y)) break;
            int b = int.Parse(y);
            if (b == 0)
            {
                
                j++;
                i--;
                Console.WriteLine(a[i]);
                Array.Clear(a, i, 1);
            }
            else
            {
                a[i] = b;
                i++;
            }
            
        }
    }
}