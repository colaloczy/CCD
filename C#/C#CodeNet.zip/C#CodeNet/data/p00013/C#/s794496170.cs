using System;
namespace aizu
{
    class OnlineJudge
    {
        static readonly int MaxSize = 10;
        static void Main()
        {
            string input;
            System.Collections.Generic.Stack<int> stack = new System.Collections.Generic.Stack<int>(MaxSize);
            while((input = Console.ReadLine()) != null){
                int number;
                if(int.TryParse(input, out number) == false){
                    continue;
                }
                if(number == 0){
                    Console.WriteLine(stack.Pop());
                }
                else{
                    stack.Push(number);
                }
            }
        }
    }
}