using System;
using System.Collections.Generic;

namespace _0013
{
    class Program
    {
        static void Main(string[] args)
        {
            var carPark = new Stack<int>();

            while (true)
            {
                var input = Console.ReadLine();

                if (string.IsNullOrEmpty(input))
                {
                    break;
                }

                if (input == "0")
                {
                    if (carPark.Count > 0)
                    {
                        var outcar = carPark.Pop();
                        Console.WriteLine(outcar);
                    }
                }
                else
                {
                    carPark.Push(int.Parse(input));
                }
            }
        }
    }
}