using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AOJ
{
    class Program
    {
        static void Main(string[] args)
        {
            var trains = new List<int>();
            string s;
            while ((s = Console.ReadLine()) != null)
            {
                int n = int.Parse(s);
                if (n == 0)
                {
                    Console.WriteLine(trains[trains.Count - 1]);
                    trains.RemoveAt(trains.Count - 1);
                }
                else
                    trains.Add(n);
            }
        }
    }
}