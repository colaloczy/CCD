using System;
using System.Collections.Generic;
using System.Linq;

static class SwitchingRailroadCars
{
    static void Main()
    {
        RepeatInfinite<Func<string>>( Console.ReadLine )
            .Select( x => x() )
            .TakeWhile( x => x != null )
            .Select( int.Parse )
            .Aggregate(
                new { st = new Stack<int>(), sq = new List<int>() },
                (x, y) => {
                    if ( y > 0 )
                        x.st.Push( y );
                    else
                        x.sq.Add( x.st.Pop() );
                    return new { st = x.st, sq = x.sq };
                    },
                x => x.sq )
            .ForEach( Console.WriteLine );
    }

    static IEnumerable<TSource> RepeatInfinite<TSource>(TSource value)
    {
        while ( true )
            yield return value;
    }
}