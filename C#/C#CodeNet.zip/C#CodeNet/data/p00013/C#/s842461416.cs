using System;
using System.Collections.Generic;

namespace AOJ.Volume0
{
    class SwitchingRailroadCars
    {
        public static void Main()
        {
            Stack<int> train = new Stack<int>();

            while (true)
            {
                string input = Console.ReadLine();
                if (string.IsNullOrEmpty(input)) { break; }
                int no = int.Parse(input);
                if (no == 0)
                {
                    // 電車が出て行く
                    Console.WriteLine(train.Pop());
                }
                else { train.Push(no); }
            }
        }
    }
}