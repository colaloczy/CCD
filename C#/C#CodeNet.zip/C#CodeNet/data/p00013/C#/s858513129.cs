using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AOJ
{
    class railroad
    {
        static void Main(string[] args)
        {
            Stack<int> cars = new Stack<int>();
            List<int> result = new List<int>();
            while(true)
            {
                string line = System.Console.ReadLine();
                if (string.IsNullOrEmpty(line))
                {
                    break;
                }
                int n = int.Parse(line);
                if(n==0)
                {
                    result.Add(cars.Pop());
                }
                else
                {
                    cars.Push(n);
                }
            }
            foreach(int x in result)
            {
                System.Console.WriteLine(x);
            }
        }
    }
}