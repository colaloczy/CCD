using System;
using System.Collections.Generic;
namespace _0013
{
    class Program
    {
        static void Main(string[] args)
        {

            List<string> aru1 = new List<string> { };
           while (true)
            {
                string s = Console.ReadLine();
                if (s == null) { break; }
                if (s == "0") { Console.WriteLine(aru1[aru1.Count - 1]); aru1.Remove(aru1[aru1.Count - 1]); }
                else { aru1.Add(s); }
            }
            Console.ReadLine();

        }
    }
}