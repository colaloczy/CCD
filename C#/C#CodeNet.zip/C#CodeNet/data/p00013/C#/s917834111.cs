using System;
using System.Collections.Generic;

namespace Switching_Railroad_Cars
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> nums = new List<int>();
            List<int> ans = new List<int>();


            while(true)
            {
                string input = Console.ReadLine();
                if (input == null)
                {
                    break;
                }

                int temp = int.Parse(input);
                if (temp == 0)
                {
                    Console.WriteLine(nums[nums.Count-1]);
                    nums.RemoveAt(nums.Count - 1);
                }
                else
                {
                    nums.Add(temp);
                }


            }

        }
    }
}

