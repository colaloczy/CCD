using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace test
{


    class Program
    {
        static void Main(string[] args)
        {
            List<int> trainList = new List<int>();
            List<int> outTrainList = new List<int>();

            string input;
            while ((input = Console.ReadLine()) != null)
            {
                int a = int.Parse(input);
                if (a == 0)
                {
                    int outTrain = trainList[trainList.Count - 1];
                    trainList.RemoveAt(trainList.Count - 1);
                    outTrainList.Add(outTrain);
                }
                else
                {
                    trainList.Add(a);
                }

            }

            foreach (int t in outTrainList)
            {
                Console.WriteLine(t);
            }


        }


    }
}