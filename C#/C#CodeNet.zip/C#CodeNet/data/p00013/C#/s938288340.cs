using System;
using System.Collections.Generic;

namespace Aizu
{
    class OnlineJudge
    {
        public static void Main()
        {
            var stack = new Stack<string>(10);
            for(string num; (num = Console.ReadLine()) != null; ) {
                if(num == "0") {
                    Console.WriteLine(stack.Pop());
                } else {
                    stack.Push(num);
                }
            }
        }
    }
}