using System;
using System.Collections;

class AOJ{
  static void Main(string[] args)
  {
    var stack = new Stack();
    string s;

    while ((s = Console.ReadLine()) != null){

      if (s == "0")
        Console.WriteLine(stack.Pop());

      else
        stack.Push(s);
    }
  }
}