using System;
namespace ConsoleApplication1{
    class Program{
        static void Main(string[] args){
            int ptr = 0;
            int[] stack = new int[10];
            String str;
		    while((str=Console.ReadLine())!=null){
                int x = int.Parse(str); ;
			    if(x==0){
				    if(stack[ptr-1]!=0){
                        Console.WriteLine(stack[ptr - 1]);
					    stack[ptr-1]=0;
					    ptr--;
				    }
			    }else{
				    stack[ptr]=x;
				    ptr++;
			    }
		    }
        }
    }
}