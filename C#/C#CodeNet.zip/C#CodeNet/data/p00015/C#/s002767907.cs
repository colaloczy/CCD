using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static readonly int MAX = 81;

        static void Main(string[] args)
        {
            StringBuilder sb = new StringBuilder();

            int[] sum = new int[MAX];

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string input1 = Console.ReadLine();
                int len = input1.Length;

                string input2 = Console.ReadLine();
                len = Math.Max(len, input2.Length);

                if (len > 80)
                {
                    sb.AppendLine("overflow");
                    continue;
                }

                int[] a = MakeArray(input1);
                int[] b = MakeArray(input2);

                for (int j = 0; j < len; j++)
                {
                    int temp = a[j] + b[j] + sum[j];

                    if (temp >= 10)
                    {
                        sum[j + 1] = 1;
                        sum[j] = temp % 10;
                    }
                    else sum[j] = temp;
                }

                if (sum[MAX - 1] > 0)
                {
                    sb.AppendLine("overflow");
                    continue;
                }

                if (sum[len] > 0) sb.Append(sum[len]);

                for (int j = len - 1; j >= 0; j--) sb.Append(sum[j]);

                sb.Append("\n");
            }
            Console.Write(sb);
        }

        static int[] MakeArray(string s)
        {
            int[] ret = new int[MAX];
            int count = 0;

            for (int j = s.Length - 1; j >= 0; j--)
            {
                ret[count] = int.Parse(s[j].ToString());
                count++;
            }
            return ret;
        }
    }
}