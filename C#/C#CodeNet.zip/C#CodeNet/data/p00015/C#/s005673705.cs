//たぶん方向性を大きく間違えたんだと思う

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace AOJ0015
{
    class Program
    {
        static void Main()
        {
            var count = int.Parse(Console.ReadLine() ?? "");

            for (var i = 0; i < count; i++)
            {
                // BigIntegerは4からなんだそうな
                var value1 = BigDecimal.Parse(Console.ReadLine() ?? "");
                var value2 = BigDecimal.Parse(Console.ReadLine() ?? "");
                var result = value1 + value2;

                if (value1.ToString().Count() > 80 || value2.ToString().Count() > 80
                    || result.ToString().Count() > 80)
                {
                    Console.WriteLine("overflow");
                }
                else
                {
                    Console.WriteLine(result);
                }
            }
        }
    }

    public class BigDecimal : IComparable
    {
        private readonly List<char> _digits = new List<char>();
        private bool _positive = true;

        private BigDecimal()
        {
        }

        public BigDecimal(Decimal d) : this(Parse(d.ToString(CultureInfo.InvariantCulture)))
        {
        }

        public BigDecimal(BigDecimal b)
        {
            _digits = new List<char>(b._digits);
            _positive = b._positive;
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.Append(_positive ? "" : "-");

            for (var i = _digits.Count - 1; i >= 0; i--)
            {
                sb.Append(_digits[i]);
            }

            return sb.ToString();
        }

        protected bool Equals(BigDecimal other)
        {
            return _positive.Equals(other._positive) && _digits.SequenceEqual(other._digits);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != GetType()) return false;
            return Equals((BigDecimal) obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                // 結構怪しい
                return (_positive.GetHashCode()*397) ^ (_digits != null ? _digits.GetHashCode() : 0);
            }
        }

        public static bool operator ==(BigDecimal b1, BigDecimal b2)
        {
            if (ReferenceEquals(b1, b2)) return true;
            if (ReferenceEquals(null, b1)) return false;
            return b1.Equals(b2);
        }

        public static bool operator !=(BigDecimal b1, BigDecimal b2)
        {
            return !(b1 == b2);
        }

        public int CompareTo(object obj)
        {
            var b = obj as BigDecimal;
            if(b == null) throw new ArgumentNullException();

            if (this == b) return 0;

            if (_positive && !b._positive) return 1;
            if (!_positive && b._positive) return -1;
            if (_positive && b._positive) return CompareOnlyDigits(b);
            if (!_positive && !b._positive) return CompareOnlyDigits(b)*-1;

            throw new Exception();
        }

        private int CompareOnlyDigits(BigDecimal b)
        {
            if (_digits.SequenceEqual(b._digits)) return 0;
            if (_digits.Count > b._digits.Count) return 1;
            if (_digits.Count < b._digits.Count) return -1;
            for (var i = _digits.Count - 1; i >= 0; i--)
            {
                if (_digits[i] > b._digits[i]) return 1;
                if (_digits[i] < b._digits[i]) return -1;
            }

            throw new Exception();
        }

        public static BigDecimal Parse(string str)
        {
            var result = new BigDecimal();

            var firstChar = true;
            foreach (var c in str)
            {
                switch (c)
                {
                    case '+':
                        if (firstChar) result._positive = true;
                        else throw new FormatException();
                        break;
                    case '-':
                        if (firstChar) result._positive = false;
                        else throw new FormatException();
                        break;
                    default:
                        if(!char.IsNumber(c)) throw new FormatException();
                        result._digits.Insert(0, c);
                        break;
                }

                firstChar = false;
            }

            return result;
        }

        public static BigDecimal operator +(BigDecimal d)
        {
            return new BigDecimal(d);
        }

        public static BigDecimal operator -(BigDecimal d)
        {
            return Parse("-" + d);
        }

        public static BigDecimal operator +(BigDecimal d1, BigDecimal d2)
        {
            var result = new BigDecimal();

            if (d1.CompareOnlyDigits(d2) > 0)
            {
                result._positive = d1._positive;
            }
            else if (d1.CompareOnlyDigits(d2) < 0)
            {
                result._positive = d2._positive;

                var temp = d1;
                d1 = d2;
                d2 = temp;
            }

            bool subtract = d1._positive != d2._positive;
            var position = 0;
            var carryBorrow = false;

            while (true)
            {
                if (position >= d1._digits.Count)
                {
                    if (carryBorrow)
                    {
                        if(subtract) throw new Exception();
                        result._digits.Add('1');
                    }

                    break;
                }

                var d1Digit = int.Parse(d1._digits[position].ToString(CultureInfo.InvariantCulture));
                int? d2Digit = null;
                if (position < d2._digits.Count())
                {
                    d2Digit = int.Parse(d2._digits[position].ToString(CultureInfo.InvariantCulture));
                }

                int newDigit;

                if (d2Digit != null)
                {
                    newDigit = (int)(d1Digit + d2Digit + (subtract ? -1 : 1) * (carryBorrow ? 1 : 0));
                }
                else
                {
                    newDigit = d1Digit + (subtract ? -1 : 1) * (carryBorrow ? 1 : 0);
                }

                if (newDigit >= 10)
                {
                    newDigit -= 10;
                    carryBorrow = true;
                }
                else if(newDigit < 0)
                {
                    newDigit += 10;
                    carryBorrow = true;
                }
                else
                {
                    carryBorrow = false;
                }

                result._digits.Add(newDigit.ToString(CultureInfo.InvariantCulture)[0]);

                position++;
            }

            if (result._digits.Count >= 2)
            {
                while (result._digits.Last() == '0')
                {
                    result._digits.RemoveAt(result._digits.Count - 1);
                }
            }

            return result;
        }

        public static BigDecimal operator -(BigDecimal d1, BigDecimal d2)
        {
            return d1 + (-d2);
        }
    }
}