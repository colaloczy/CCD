using System;
using System.Linq;

namespace Volume0_0015
{
    class Program
    {
        static void Main(string[] args)
        {
            var count = Convert.ToInt32(Console.ReadLine());
            for(var i = 0; i < count; i++)
            {
                var num1 = new BigInteger(Console.ReadLine());
                var num2 = new BigInteger(Console.ReadLine());
                var ans = num1 + num2;
                Console.WriteLine(ans.Digit > 80 ? "overflow" : ans.ToString());
            }
        }
    }

    // ?????????
    public class BigInteger
    {
        public const int maxDigit = 8;

        public int Digit
        {
            get
            {
                if (Next == null) return Number.ToString().Length;
                return Next.Digit + Number.ToString().Length;
            }
        }

        string Number;
        BigInteger Next = null;

        public BigInteger(string num)
        {
            Number = new string(num.Skip(num.Length - maxDigit).ToArray());
            var remain = new string(num.Take(num.Length - maxDigit).ToArray());
            if (remain.Length != 0) Next = new BigInteger(remain);
        }
        
        public static BigInteger operator +(BigInteger a, BigInteger b)
        {
            return Add(a, b);
        }      

        public static BigInteger Add(BigInteger a, BigInteger b, BigInteger newInt = null)
        {
            if (a == null && b == null && newInt == null) return null;
            else if (a == null && b == null) return newInt;
            else if (a != null && b == null)
            {
                if (newInt == null) newInt = new BigInteger("0");
                newInt.Number = (Convert.ToInt32(a.Number) + Convert.ToInt32(newInt.Number)).ToString("D8");
                CheckCarry(newInt);
                newInt.Next = Add(a.Next, null, newInt.Next);
            }
            else if (a == null && b != null)
            {
                if (newInt == null) newInt = new BigInteger("0");
                newInt.Number = (Convert.ToInt32(b.Number) + Convert.ToInt32(newInt.Number) ).ToString("D8");
                CheckCarry(newInt);
                newInt.Next = Add(null, b.Next, newInt.Next);
            }
            else
            {
                if (newInt == null) newInt = new BigInteger("0");
                newInt.Number = (Convert.ToInt32(a.Number) + Convert.ToInt32(b.Number) + Convert.ToInt32(newInt.Number)).ToString("D8");
                CheckCarry(newInt);
                newInt.Next = Add(a.Next, b.Next, newInt.Next);
            }
            if (newInt.Next == null)
            {
                for (var i = 0; i < maxDigit; i++)
                {
                    if (newInt.Number[0] != '0') break;
                    newInt.Number = new string(newInt.Number.Skip(1).ToArray());
                }
            }
            return newInt;
        }

        protected static void CheckCarry(BigInteger bigint)
        {
            if (bigint.ToString().Length > maxDigit)
            {
                bigint.Number = new string(bigint.Number.Skip(1).ToArray());
                bigint.Next = new BigInteger("1");
            }
        }

        public override string ToString()
        {
            if (Next == null) return Number.ToString();
            else return Next.ToString() + Number;
        }
    }
}