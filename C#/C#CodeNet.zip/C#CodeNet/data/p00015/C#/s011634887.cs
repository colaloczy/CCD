using System;

class main
{
    static void Main(string[] args)
    {
        string s1, s2, a4;
        int c = int.Parse(Console.ReadLine());
        for (int m = 0; m < c; m++)
        {
            s1 = Console.ReadLine();
            s2 = Console.ReadLine();
            a4 = string.Empty;
            ulong a1 = 0, a2 = 0;
            string[] s3 = new string[5];
            string[] s4 = new string[5];
            string[] s5 = new string[5];
            ulong[] a3 = new ulong[5];
            if (s1.Length > 80 || s2.Length > 80)
            {
                Console.WriteLine("overflow");
                goto end;
            }
            s1 = s1.PadLeft(80, '0');
            s2 = s2.PadLeft(80, '0');
            for (int i = 0; i < 5; i++)
            {
                s3[i] = s1.Substring(16 * i, 16);
                s4[i] = s2.Substring(16 * i, 16);
            }
            for (int j = 4; j >= 0; j--)
            {
                a1 = ulong.Parse(s3[j]);
                a2 = ulong.Parse(s4[j]);
                a3[j] += a1 + a2;
                if (a3[j].ToString().Length == 17)
                {
                    if (j == 0)
                    {
                        Console.WriteLine("overflow");
                        goto end;
                    }
                    a3[j] -= 10000000000000000;
                    a3[j - 1] += 1;
                }
                s5[j] = a3[j].ToString().PadLeft(16, '0');
            }
            a4 = string.Join("", s5);
            while (a4.StartsWith("0"))
            {
                a4 = a4.TrimStart('0');
                if (a4 == "")
                {
                    Console.WriteLine(0);
                    goto end;
                }
            }
            Console.WriteLine(a4);
        end: ;
        }
    }
}